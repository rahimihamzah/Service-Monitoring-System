<?php
session_start();

//if (isset($_SESSION['username'])) {
  //unset($_SESSION["username"]); 
//}
?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  
  
  
  <link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css'>

      <link rel="stylesheet" href="css/style_login.css">

  
</head>

<body>
	  
      <div class="wrapper">
      <form class="form-signin" action="login_submit.php" method="POST">       
      <h4 class="form-signin-heading" align="center"><u>Service Monitoring System Sign-On</u></h4>
      <input type="text" class="form-control" id="username" name="username" placeholder="User ID" required="" autofocus="" value="admin" />
      <br>
      <input type="password" class="form-control" id="password" name="password" placeholder="Password" required="" value="rahimi" />      
      <br>
      
                            <div style="margin-left: 90px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="reset" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                            
							
      
    </form>
  </div>
  
  
</body>
</html>