<?php
include "connection.php";

$id=$_POST['id'];
$pass=$_POST['user_pass'];
$pass1=$_POST['user_pass1'];

$sql="select * from [user] where user_id='$id'";
$res=sqlsrv_query($conn,$sql);
$row=sqlsrv_fetch_array($res,SQLSRV_FETCH_ASSOC);

if($row['password']==null)
{
	if($pass==$pass1)
	{
		$sql2="update [user] set password='$pass' where user_id='$id'";
		if(sqlsrv_query($conn,$sql2))
		{
                    $message = "Your Password is Successfully Set!";
    echo "<script type='text/javascript'>alert('$message');
			window.location = 'index.php';</script>";
		}
		else
		{
			$message = "Error Message : Problem password!";
    echo "<script type='text/javascript'>alert('$message');
			window.location = 'user_password.php';</script>";
		}
	}
	else
	{
		echo "Password do not match!";
	}
}
else
{
	echo "Password has been set before!";
}
?>