<?php
include ('../connection.php');
?>



<h5><b><u>
        ADD ROLE
        </u></b></h5>
        
         <form action="function_add_role.php" method="post">
         				<table><tr><td>
                        			    	  	
                        <label for="RoleId">Role ID </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="role_id" id="RoleId" type="text"  required>   *no space
			 <script>
				document.getElementById('RoleId').onkeydown = function (event) {

 					 var key = event.keyCode || event.which; 
 
 					 if (key == 32) { //Space bar key code
  					  //Prevent default action, which is inserting space
  					  if (event.preventDefault) event.preventDefault(); //normal browsers
    				event.returnValue = false; //IE
						  }
						};
						</script>
			    		    
			    		</td>
                        </tr>
                        <td>&nbsp; </td>
                        <tr><td>
                        <label for="Description">Description </label>&nbsp;&nbsp;</td>
                        <td>
                        	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			    		    <input name="description" type="text" style="width: 300px;" required>
                        </td>
                        </tr>
                        </table>
                        
			    		
                            
                        <br>
                        <br>
                        
        <h5><b>
        Accessible Module
        </b></h5>
         				<br>
                                                
         <h5><u>
        Service Request Order
        </u></h5>
        				                        
                        <div class="checkbox">
                        <table><tr><td>
                                    <label class="checkbox-inline">
                                     <input type="checkbox" name="sro[]" value="Add SRO">Add SRO</td>
                                    </label>
                                   <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                    <input type="checkbox" name="sro[]" value="Edit SRO">Edit SRO</td>
                                    </label>
                                  <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                     <input type="checkbox" name="sro[]" value="View/Delete sro">View/Delete SRO</td></tr>
                                    </label>
                                    
                                </div>
                                <div class="checkbox">
                                   <tr><td> 
                                   <label>
                                        <input type="checkbox" name="sro[]" value="SRO Approval By BO">SRO Approval by BO </td>                                   </label>
                                </div>
                                <div class="checkbox">
                                 <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="checkbox" name="sro[]" value="SRO Approval By HTP">SRO Approval By HTP</td></tr></table>
                                    </label>
                                </div>
                            
                            <br>
                            
        <h5><u>
        Biling
        </u></h5>
                   
                    <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="billing[]" value="Add Quotation" />Add Quotation</td></label>
                            
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="Add LOA" />Add LOA</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="Add ATB" />Add ATB</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="Add Invoice" />Add Invoice</td></tr></label>
                           
                           <tr><td>
                           <label class="checkbox-inline">
                           <input type="checkbox" name="billing[]" value="Update Payment" />Update Payment</td></tr></label>
                           </table>
                           </div>         
                            <br>
                           
                           
                           
        <h5><u>
        Service Execution Order
        </u></h5>    
                           <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="seo[]" value="Add SEO" />Add SEO</td></label>
                            
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="Edit SEO" />Edit SEO</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="View/Delete SEO" />View/Delete SEO</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="Update Finance Status" />Update Finance Status</td></tr></label>
                           </table>
                           
                           
                           <br>
                           
        <h5><u>
        View Document
        </u></h5>  
        
        			      <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="doc" value="View All Documents" />View All Documents</td></tr></label> 
                            </table>
                            </div>   
                            
                            <br>
                            
        <h5><u>
        Administration
        </u></h5>
        				<div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="Add Customer" />Add Customer</td></label>
                         
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="Customer Maintenance" />Customer Maintenance</td></tr></label> 
                         
                        <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="Add Role" />Add Role</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="Role Maintenance" />Role Maintenance</td></tr></label>
                                  
                         <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="Add User" />Add User</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="User Maintenance" />User Maintenance</td></tr></label> 
                         
                         <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="Add Project" />Add Project</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                         <input type="checkbox" name="admin[]" value="Project Maintenance" />Project Maintenance</td></tr></label>
                          </table>
                          </div>
                          <br>
                         
        <h5><u>
        System Configuration
        </u></h5> 
        
        				<div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="config[]" value="Reset Password" />Reset Password</td></tr></label>
                            </table>
                            </div>
                            
                            <br>
                            <br>
                            
                            <div style="margin-left: 250px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="Save"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                            
                            
                          
                          
                            
			    		
			      	</form>
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



