<?php
include ("header.php");
include ("../connection.php");

$strCustomerID = null;

   if(isset($_GET["user_id"]))
   {
	   $strCustomerID = $_GET["user_id"];
   
   }


 if( $conn === false ) {
      die( print_r( sqlsrv_errors(), true));
   }

	$stmt = "SELECT * FROM [user] WHERE user_id = ? ";
	$stmt2 = "SELECT * FROM role ";
	$params = array($strCustomerID);

	$query = sqlsrv_query( $conn, $stmt, $params);
	$query2 = sqlsrv_query( $conn, $stmt2);

	$result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);
	
	echo $strCustomerID;
	//}



?>

  <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
          
            <!-- /.row -->

                   
            
 		<h5><b><u>
        ADD USER
        </u></b></h5>
        <br>
 		
         				<form action="user_edit_submit.php" method="post">
         				<table><tr><td>
                        <label for="UserId">User ID </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text"  value="<?php echo $result['user_id'];?>" disabled>
                        <input name="user_id" type="hidden" value="<?php echo $result['user_id'];?>">
			    		
                        </td>
                        </tr>
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Username">Username </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="username" type="text" style="width: 300px;" value="<?php echo $result['username'];?>  "required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Designation">Designation </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="designation" type="text" style="width: 300px;" value=" <?php echo $result['user_designation'];?>  "required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="UserRole">User Role </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <select name="user_role" style="width: 300px; height:27px;"  required="true">
                        <?php echo "<option value='".$result['role_id']."'>".$result['role_id']."</option>";
						?>
                        	<option value="">Select</option>
                            <?php
							while($row2 = sqlsrv_fetch_array($query2)){
                            echo "<option value='".$row2['role_id']."'>".$row2['role_id']."</option>";
							}
							?>
                         </select>                                          
                        </td>
                        </tr>
                        
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Email">Email</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="email" type="text" pattern="[^ @]*@[^ @]*" style="width: 300px;" value=" <?php echo $result['email'];?> "required>
                        </td>
                        </tr>
                        </table>
                        
                        <br />
                         <div style="margin-left: 144px;" >
                            <table><tr><td>
                            <input type="hidden" name="user_id" value="<?php echo $result['user_id'] ?>">
   							<input class="btn btn-info" type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel" onClick="document.location.href='user_maintenance.php'"></td>
                            </tr>
                            </table>
							</div>
                         </form> 
                            
			    		
			      	
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



