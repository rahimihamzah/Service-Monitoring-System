<?php
include "../connection.php";

//$url_file = basename($_SERVER['PHP_SELF']); /* Returns The Current PHP File Name */
//echo $url_file;

//dapatkan user_id punya session
if(session_id() == '' || !isset($_SESSION)) {
    // session isn't started
    session_start();
    
    if($_SESSION["username"] != "" || !empty($_SESSION["username"])){
        $user_id2 = $_SESSION["username"];
    }
 else {
        $user_id2 = "";
        
        header("Location: index.php");
    }
}

//$role_id=$_SESSION['role_id'];
//echo $user_id2;

$sql_a="SELECT * FROM [user] where user_id=?";
$params_a = array($user_id2);
$options_a = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
$query_a = sqlsrv_query($conn, $sql_a, $params_a, $options_a);
$result_a = sqlsrv_fetch_array($query_a, SQLSRV_FETCH_ASSOC);
//$role_id = $result_a['role_id'];
//echo $role_id;
//print_r($_SESSION);
//die();



    
    

//$user_id3 = $_SESSION["user_id"];
//die($url_file.":1:".$user_id2.":2:".$user_id3);

//cek 2 parameters ni dlm table; user_task
//kalau wujud, benarkan view page ni, kalo xde, redirect ke page error
/*$sql = "SELECT a.*, b.*, c.* FROM [user] a left join task b on b.user_id = a.id_admin left join url c on c.url_id = b.url_id where b.user_id = '$user_id2' and c.link = '$url_file'";

$params = array();
$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );

$stmt = sqlsrv_query( $conn, $sql , $params, $options );

//cek kalau query salah
if ($stmt === false){
  //echo "a";
  //die("Please check the query");
} else{
  //echo "b";

//kire bilangan rekod
$row_count = sqlsrv_num_rows($stmt);
echo $row_count;
die($url_file.":".$row_count);



if ($row_count<1)
{
  header("Location: ../authorized.php"); 
  
}
else
{
  echo "azizi";
}
}
 * 
 */
/*
$stmt0 = "SELECT a.*, b.* FROM task a left join url b on b.url_id = a.url_id WHERE a.role_id = ? and b.link = ? and a.user_id = ?";
//echo $role_id."<p>".$url_file."<p>".$user_id2;
//die();
$params0 = array($role_id, $url_file, $user_id2);
$options = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
$query0 = sqlsrv_query($conn, $stmt0, $params0, $options);
$result0 = sqlsrv_fetch_array($query0, SQLSRV_FETCH_ASSOC);

//die($strCustomerID.":".$url_file.":".$session_admin);

if ($query0 === false) {
    if (($errors = sqlsrv_errors() ) != null) {
        foreach ($errors as $error) {
            echo "SQLSTATE: " . $error['SQLSTATE'] . "<br />";
            echo "code: " . $error['code'] . "<br />";
            echo "message: " . $error['message'] . "<br />";
        }
    }
} else {
    $row_count = sqlsrv_num_rows($query0);
    if ($row_count > 0) {
        //echo "has data";
    header("Location: home.php");
    
*
 * 
 */
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Service Monitoring System</title>
    

    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/bootstrap/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="bootstrap/bootstrap/dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="bootstrap/bootstrap/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="bootstrap/bootstrap/bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="bootstrap/bootstrap/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
              <a class="navbar-brand" href="home.php"><p><img src="../img/logo.png" alt="Logo Heitech" style="height:30px;"><h5><i>HeiTech</h5></i></p></a>
              
             
            <!-- /.navbar-header -->


            <!-- /.navbar-top-links -->
<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
            
            
                <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#sro"><i class="fa fa-circle-o-notch"></i> SRO <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="sro" class="collapse">
            
            
              
                          <p><a href="add_sro.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add New SRO</a></p>
                        
                          <p><a href="edit_sro.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Service Request Order</a></p>
                                                
                          <p><a href="view_sro.php"><i class="fa fa-list" aria-hidden="true"></i> View/Delete SRO</a></p>
                                                
                          <p><a href="approval_cbw.php"><i class="fa fa-check-circle" aria-hidden="true"></i> Approval by Client Business Owner</a></p>
                          
                          <p><a href="approval_his.php"><i class="fa fa-check-circle" aria-hidden="true"></i> Approval by HIS</a></p>
                          </ul>
                        
                  </li>
                  
                   <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#biling"><i class="fa fa-circle-o-notch"></i> Billing <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="biling" class="collapse">
            
            
              
                          <p><a href="dis_quotation.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Quotation</a></p>
                        
                          <p><a href="dis_loa.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload LOA</a></p>
                                                
                          <p><a href="dis_atb.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Advice To Bill</a></p>
                                                
                          <p><a href="dis_invoice.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Invoice</a></p>
                          
                          <p><a href="dis_update_payment.php"><i class="fa fa-pencil" aria-hidden="true"></i> Update Payment</a></p>
                          </ul>
                        
                        
                        
                        
                  </li>
                  
                  <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#seo"><i class="fa fa-circle-o-notch"></i> SEO <i class="fa fa-fw fa-caret-down"></i></a>
                  
                      <ul id="seo" class="collapse">
                        
                        <p><a href="dis_seo.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add New SEO</a></p>
                        
                          <p><a href="dis_edit_seo.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit SEO</a></p>
                                                
                          <p><a href="dis_view_seo.php"><i class="fa fa-list" aria-hidden="true"></i> View/Delete SEO</a></p>
                                                
                          <p><a href="dis_update_seo_status.php"><i class="fa fa-pencil" aria-hidden="true"></i> Update SEO Status</a></p>
                          
                          </ul>
                          </li>
                                                 
                         
                  
                        
            
                <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#admin"><i class="fa fa-circle-o-notch"></i> Admin <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="admin" class="collapse">
            
            
              
                          <p><a href="index.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add Role</a></p>
                        
                          <p><a href="maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Role Maintenance</a></p>
                                                
                          <p><a href="add_user.php"><i class="glyphicon glyphicon-user" aria-hidden="true"></i> Add User</a></p>
                                                
                          <p><a href="user_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> User Maintenance</a></p>
                        
                          <p><a href="add_customer.php"><i class="fa fa-users" aria-hidden="true"></i> Add Customer</a></p>
                        
                          <p><a href="customer_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Customer Maintenance</a></p>
                        
                          <p><a href="add_project.php"><i class="fa fa-plus" aria-hidden="true"></i> Add Project</a></p>
                        
                          <p><a href="project_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Project Maintenance</a></p>
                        
                          <p><a href="system_config.php"><i class="fa fa-cog" aria-hidden="true"></i> System Configuration</a></p>
                        
                          <p><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Log Out</a></p>
                        
                        
                       </li>
             
        </div>
      </div>
            </div>
            </div>

            <!-- /.navbar-static-side -->
        </nav>
         