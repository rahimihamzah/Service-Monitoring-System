<?php
include ("header.php");
include ("../connection.php");
$sql2 = "SELECT * from role";
$result2 = sqlsrv_query ($conn, $sql2);



?>



                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            <ol class="breadcrumb">
                            	<li>
                                <i class="fa fa-edit"></i><a href="index.php" >Add Role</a>
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="maintenance.php" > Role Maintenance </a> 
                                </li>
                                <li class="active"> 
                                <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Add User
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="user_maintenance.php" > User Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_customer.php" > Add Customer </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="customer_maintenance.php" > Customer Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_project.php" > Add Project </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="project_maintenance.php" > Project Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="system_config.php" > System Configuration </a> 
                                </li>
                                
                                
                            
                            
                        </ol>
            <!-- /.row -->
 		<h5><b><u>
        ADD USER
        </u></b></h5>
        <br>
 		
         				<form action="user_submit.php" method="post">
         				<table><tr><td>
                        <label for="UserId">User ID </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="user_id" type="text"  required>
			    		
                        </td>
                        </tr>
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Username">Username </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="username" type="text" style="width: 300px;"  required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Designation">Designation </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="designation" type="text" style="width: 300px;"  required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="UserRole">User Role </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <select name="user_role" style="width: 300px; height:27px;"  required>
                        	<option disabled selected value></option>
                            <?php
							while($row2 = sqlsrv_fetch_array($result2)){
                            echo "<option value='".$row2['role_id']."'>".$row2['role_id']."</option>";
							}
							?>
                         </select>                                          
                        </td>
                        </tr>
                        
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Email">Email</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="email" type="text" pattern="[^ @]*@[^ @]*" style="width: 300px;"  required>
                        </td>
                        </tr>
                        </table>
                        
                        <br />
                         <div style="margin-left: 144px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                         </form> 
                            
			    		
			      	
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



