<?php
include ("header.php");

$conn = mysqli_connect("localhost", "root", "");
mysqli_select_db($conn,"sal");

$staff_id = $_POST['staff_id'];

$sql2 = "select * from staff where staff_id='$staff_id'";
$result2 = mysqli_query ($conn, $sql2);
$row2 = mysqli_fetch_array($result2);

?>


                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h1 class="page-header">Update User</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
              <form action="viewupdate_submit.php" method="post">
			    	  	<div class="form-group">
                        <label for="staff_name">Staff Name :</label>
			    		    <input class="form-control" placeholder="Staff Name" name="staff_name" type="text" value="<?php echo $row2['staff_name']?>" required>
			    		</div>
                        <br>
			    		<div class="form-group">
			    		<label for="staff_user">Staff Username :</label>
			    		    <input class="form-control" placeholder="Staff Username" name="staff_user" type="text" value="<?php echo $row2['staff_user']?>" required>
                        <br>
                        <div class="form-group">
			    		<label for="staff_pass">Staff Password :</label>
			    		    <input class="form-control" placeholder="Staff Password" name="staff_pass" type="text" value="<?php echo $row2['staff_pass']?>" required>
                        <br>
			    		</div>
			    		<input class="btn btn-lg btn-primary btn-block" type="submit" value="UPDATE"></center>
			      	</form>
                    <!-- Scripts -->
			<script src="../assets/js/jquery.min.js"></script>
			<script src="../assets/js/jquery.dropotron.min.js"></script>
			<script src="../assets/js/jquery.scrolly.min.js"></script>
			<script src="../assets/js/jquery.scrollgress.min.js"></script>
			<script src="../assets/js/skel.min.js"></script>
			<script src="../assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="../assets/js/main.js"></script>
            </body>
			</html>            