<?php
include ("../config.php");

$staff_name=$_POST['staff_name'];
$staff_user=$_POST['staff_user'];
$staff_pass=$_POST['staff_pass'];

$sql = "update car set staff_name='$staff_name', staff_user='$staff_user', staff_pass='$staff_pass'";


if (mysqli_query($conn, $sql)) 
{
    header ("Location: view.php");
} else {
    echo "Error";
}

mysqli_close($conn);
?>