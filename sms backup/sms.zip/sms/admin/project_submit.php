<?php
session_start();
$user=$_SESSION['username'];
$date=date("d-m-Y");
include "../connection.php";


$customer =$_POST['customer_name'];
$pcode =$_POST['project_code'];
$pname =$_POST['project_name'];
$pmanager =$_POST['project_manager'];
$emel =$_POST['email'];
$contact =$_POST['contact'];
$bo =$_POST['bus_owner'];



	$sql = "INSERT INTO project (customer_name, project_code, project_name, project_manager, email, contact_no, business_owner, date_created, created_by) VALUES ('$customer','$pcode','$pname','$pmanager','$emel','$contact','$bo','$date','$user') ";

	if(sqlsrv_query($conn,$sql))
	{
		
		echo '<script type="text/javascript">
			alert("Record Successfully Added");
				window.location = "project_maintenance.php";
			</script>';
	}
	
	else
	{
		if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}
	}
	}


?>

