<?php
session_start();
$user=$_SESSION['username'];
$date=date("Y-m-d");
include "../connection.php";


$user_id =$_POST['user_id'];
$username =$_POST['username'];
$designation =$_POST['designation'];
$user_role =$_POST['user_role'];
$email =$_POST['email'];



	$sql = "INSERT INTO [user] (user_id, username, user_designation, role_id, email, date_created, created_by) VALUES ('$user_id','$username','$designation','$user_role','$email','$date','$user') ";

	if(sqlsrv_query($conn,$sql))
	{
		$message="Please set your password here at http://localhost/sms/user_password.php?id=".$user_id."";
		$subject="PLEASE SET YOUR PASSWORD";	
		mail($email,$subject,$message);
		echo '<script type="text/javascript">
			alert("Successfully Saved");
				window.location = "user_maintenance.php";
			</script>';
	}
	
	else
	{
		if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}
	}
	}


?>

