<?php
//session_start();
//if (isset($_SESSION['username']) && !empty($_SESSION['username'])) {
include ("header.php");
?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>







  <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>
<?php
//}
//else
//{
//	header("Location:../error.php");
//}
?>