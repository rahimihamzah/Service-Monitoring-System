<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr {
    background-color: #b0b0b0;
}
</style>



<?php
include ("header.php");
//include ("../config.php");
?>

                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                 
                
                
                <!-- /.col-lg-12 -->
            </div>
            
            <ol class="breadcrumb">
                            	<li>
                                <i class="fa fa-edit"></i><a href="add_sro.php"> Add SRO </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="edit_sro.php" >Edit Service Request Order</a>
                                </li>
                                <li> 
                                <i class="fa fa-edit" aria-hidden="true"></i><a href="view_sro.php" > View/Delete SRO </a>
                                </li>
                                <li class="active"> 
                                <i class="fa fa-chevron-circle-right"></i> Approval by Client Business Owner 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="approval_his.php" > Approval by HIS </a> 
                                </li>
                                
                            
                        </ol>
            
            <!-- /.row -->
        <h5>
        Please select one of the record(s) below to approve the Service Request Order
        </h5>
        <br>
            
              <form action="register_submit.php" method="GET">
              	
                	<table class="table table-bordered ">
                    <tr>
                    	<th>Ref No</th>
                        <th>Project</th>
                        <th>Select</th>
                    </tr>
                    
                 </table>
			    	  	
			      	</form>
                    
                 
                  
                                   <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>
            </body>
			</html>            
            </div>