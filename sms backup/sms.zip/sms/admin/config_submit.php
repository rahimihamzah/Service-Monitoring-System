<?php
include "../connection.php";
function createRandomPassword() { 

    $chars = "abcdefghijkmnopqrstuvwxyz023456789"; 
    srand((double)microtime()*1000000); 
    $i = 0; 
    $pass = '' ; 

    while ($i <= 7) { 
        $num = rand() % 33; 
        $tmp = substr($chars, $num, 1); 
        $pass = $pass . $tmp; 
        $i++; 
    } 

    return $pass; 

} 

$random_code = createRandomPassword();
$user =$_POST['bus_owner'];

$sql="UPDATE [user] set password='$random_code' WHERE user_id='$user'";

if(sqlsrv_query($conn,$sql))
  {
	  
  echo '<script type="text/javascript">
			alert("Successfully Changed");
				window.location = "system_config.php";
			</script>';
  }
  else
  {
	    echo '<script type="text/javascript">
			alert("Something Going Wrong");
				window.location = system_config.php";
			</script>';
  }




?>