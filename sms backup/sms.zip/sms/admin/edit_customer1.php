<?php
  include ("../connection.php");
  $id=$_POST['customer_id'];
  $ecategory=$_POST['customer_name'];
  $equestion=$_POST['location'];
  $eop1=$_POST['hod'];
  $eop2=$_POST['email'];
  $eop3=$_POST['contact'];
  $ejawapan=$_POST['cus_type'];
  //echo $id.'<p>'.$ecategory.'<p>'.$equestion.'<p>'.$eop1.'<p>'.$eop2.'<p>'.$eop3.'<p>'.$ejawapan;
if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}
}
  $sql="UPDATE customer SET customer_name='$ecategory', location='$equestion', hod='$eop1', email='$eop2',contact_no='$eop3', customer_type='$ejawapan' WHERE customer_id='$id'";
  if(sqlsrv_query($conn,$sql))
  {
  echo '<script type="text/javascript">
			alert("Successfully Saved");
				window.location = "customer_maintenance.php";
			</script>';
  }
  else
  {
	    echo '<script type="text/javascript">
			alert("Ralat");
				window.location = edit_customer.php";
			</script>';
  }
?>
