<?php
session_start();
$user=$_SESSION['username'];
$date=date("d-m-Y");
include "../connection.php";



$pcode =$_POST['project_code'];
$pname =$_POST['project_name'];
$pmanager =$_POST['project_manager'];
$email =$_POST['email'];
$contact =$_POST['contact'];
$bowner =$_POST['bo'];

if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}
}


	$sql = "UPDATE project SET project_name='$pname', project_manager='$pmanager', email='$email', contact_no='$contact', business_owner='$bowner' WHERE project_code='$pcode'";

	if(sqlsrv_query($conn,$sql))
  {
	  
  echo '<script type="text/javascript">
			alert("Successfully Saved");
				window.location = "project_maintenance.php";
			</script>';
  }
  else
  {
	    echo '<script type="text/javascript">
			alert("Ralat");
				window.location = edit_project.php";
			</script>';
  }


?>

