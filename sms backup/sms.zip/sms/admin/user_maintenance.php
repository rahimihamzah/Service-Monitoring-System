

<?php
include ("header.php");
include ("../connection.php");
?>



                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            <ol class="breadcrumb">
                            	<li>
                                <i class="fa fa-edit"></i><a href="index.php" >Add Role</a>
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="maintenance.php" > Role Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_user.php" >Add User </a> 
                                </li>
                                <li class="active">  
                                <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> User Maintenance
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_customer.php" > Add Customer </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="customer_maintenance.php" > Customer Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_project.php" > Add Project </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="user_maintenance.php" > Project Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="system_config.php" > System Configuration </a> 
                                </li>
                                
                                
                            
                            
                        </ol>
            <!-- /.row -->
 			
 		<h5>
        Please select one of the record(s) below
        </h5>
        <br>
 			
 		
        
              		<center>
                	<table class="table table-striped table-hover">
                    
                    <tr>
                    	<th>User ID</th>
                        <th>Edit</th>
                        <th>View/Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    
                    
			    	  	
			      	<?php
					
					$sql="select * from [user]";
					$result= sqlsrv_query($conn,$sql);
		
					while($row = sqlsrv_fetch_array($result))
					{
						?>
                        
				<tr>
                <td><?php echo $row["user_id"];?>
				</td>
				<td><a href='edit_user.php?user_id=<?php echo $row["user_id"];?>'>Edit</a></td>
				<td><a href='view_delete_user.php?user_id=<?php echo $row["user_id"];?>'>View/Delete</td>
				</tr>
			
				<?php
			
					}
					
					
					
					?>
  
</table>

			    		
			      	
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



