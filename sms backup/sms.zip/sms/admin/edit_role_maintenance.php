<?php
include ("header.php");
include ('../connection.php');

$strCustomerID = null;

   if(isset($_GET["role_id"]))
   {
	   $strCustomerID = $_GET["role_id"];
   
   }

	$stmt = "SELECT * FROM role WHERE role_id = ?";
	$stmt1 = "SELECT count(*) as stmt1 FROM task WHERE role_id = ? and url_id='5'";
	$stmt2 = "SELECT count(*) as stmt2 FROM task WHERE role_id = ? and url_id='30'";
	$stmt3 = "SELECT count(*) as stmt3 FROM task WHERE role_id = ? and url_id='48'";
	$stmt4 = "SELECT count(*) as stmt4 FROM task WHERE role_id = ? and url_id='7'";
	$stmt5 = "SELECT count(*) as stmt5 FROM task WHERE role_id = ? and url_id='8'";
	$stmt6 = "SELECT count(*) as stmt6 FROM task WHERE role_id = ? and url_id='21'";
	$stmt7 = "SELECT count(*) as stmt7 FROM task WHERE role_id = ? and url_id='20'";
	$stmt8 = "SELECT count(*) as stmt8 FROM task WHERE role_id = ? and url_id='13'";
	$stmt9 = "SELECT count(*) as stmt9 FROM task WHERE role_id = ? and url_id='19'";
	$stmt10 = "SELECT count(*) as stmt10 FROM task WHERE role_id = ? and url_id='22'";
	$stmt11 = "SELECT count(*) as stmt11 FROM task WHERE role_id = ? and url_id='3'";
	$stmt12 = "SELECT count(*) as stmt12 FROM task WHERE role_id = ? and url_id='16'";
	$stmt13 = "SELECT count(*) as stmt13 FROM task WHERE role_id = ? and url_id='24'";
	$stmt14 = "SELECT count(*) as stmt14 FROM task WHERE role_id = ? and url_id='23'";
	$stmt15 = "SELECT count(*) as stmt15 FROM task WHERE role_id = ? and url_id='51'";
	$stmt16 = "SELECT count(*) as stmt16 FROM task WHERE role_id = ? and url_id='1'";
	$stmt17 = "SELECT count(*) as stmt17 FROM task WHERE role_id = ? and url_id='9'";
	$stmt18 = "SELECT count(*) as stmt18 FROM task WHERE role_id = ? and url_id='34'";
	$stmt19 = "SELECT count(*) as stmt19 FROM task WHERE role_id = ? and url_id='35'";
	$stmt20 = "SELECT count(*) as stmt20 FROM task WHERE role_id = ? and url_id='6'";
	$stmt21 = "SELECT count(*) as stmt21 FROM task WHERE role_id = ? and url_id='43'";
	$stmt22 = "SELECT count(*) as stmt22 FROM task WHERE role_id = ? and url_id='2'";
	$stmt23 = "SELECT count(*) as stmt23 FROM task WHERE role_id = ? and url_id='36'";
	$stmt24 = "SELECT count(*) as stmt24 FROM task WHERE role_id = ? and url_id='52'";
	
	
	
	$params = array($strCustomerID);

	$query = sqlsrv_query( $conn, $stmt, $params);
	$query1 = sqlsrv_query( $conn, $stmt1,$params);
	$query2 = sqlsrv_query( $conn, $stmt2, $params);
	$query3 = sqlsrv_query( $conn, $stmt3, $params);
	$query4 = sqlsrv_query( $conn, $stmt4, $params);
	$query5 = sqlsrv_query( $conn, $stmt5, $params);
	$query6 = sqlsrv_query( $conn, $stmt6, $params);
	$query7 = sqlsrv_query( $conn, $stmt7, $params);
	$query8 = sqlsrv_query( $conn, $stmt8, $params);
	$query9 = sqlsrv_query( $conn, $stmt9, $params);
	$query10 = sqlsrv_query( $conn, $stmt10, $params);
	$query11 = sqlsrv_query( $conn, $stmt11, $params);
	$query12 = sqlsrv_query( $conn, $stmt12, $params);
	$query13 = sqlsrv_query( $conn, $stmt13, $params);
	$query14 = sqlsrv_query( $conn, $stmt14, $params);
	$query15 = sqlsrv_query( $conn, $stmt15, $params);
	$query16 = sqlsrv_query( $conn, $stmt16, $params);
	$query17 = sqlsrv_query( $conn, $stmt17, $params);
	$query18 = sqlsrv_query( $conn, $stmt18, $params);
	$query19 = sqlsrv_query( $conn, $stmt19, $params);
	$query20 = sqlsrv_query( $conn, $stmt20, $params);
	$query21 = sqlsrv_query( $conn, $stmt21, $params);
	$query22 = sqlsrv_query( $conn, $stmt22, $params);
	$query23 = sqlsrv_query( $conn, $stmt23, $params);
	$query24 = sqlsrv_query( $conn, $stmt24, $params);
	

	$result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);
	$row = sqlsrv_fetch_array( $query1, SQLSRV_FETCH_ASSOC );
	$row1 = sqlsrv_fetch_array( $query2, SQLSRV_FETCH_ASSOC );
	$row2 = sqlsrv_fetch_array( $query3, SQLSRV_FETCH_ASSOC );
	$row3 = sqlsrv_fetch_array( $query4, SQLSRV_FETCH_ASSOC );
	$row4 = sqlsrv_fetch_array( $query5, SQLSRV_FETCH_ASSOC );
	$row5 = sqlsrv_fetch_array( $query6, SQLSRV_FETCH_ASSOC );
	$row6 = sqlsrv_fetch_array( $query7, SQLSRV_FETCH_ASSOC );
	$row7 = sqlsrv_fetch_array( $query8, SQLSRV_FETCH_ASSOC );
	$row8 = sqlsrv_fetch_array( $query9, SQLSRV_FETCH_ASSOC );
	$row9 = sqlsrv_fetch_array( $query10, SQLSRV_FETCH_ASSOC );
	$row10 = sqlsrv_fetch_array( $query11, SQLSRV_FETCH_ASSOC );
	$row11 = sqlsrv_fetch_array( $query12, SQLSRV_FETCH_ASSOC );
	$row12 = sqlsrv_fetch_array( $query13, SQLSRV_FETCH_ASSOC );
	$row13 = sqlsrv_fetch_array( $query14, SQLSRV_FETCH_ASSOC );
	$row14 = sqlsrv_fetch_array( $query15, SQLSRV_FETCH_ASSOC );
	$row15 = sqlsrv_fetch_array( $query16, SQLSRV_FETCH_ASSOC );
	$row16 = sqlsrv_fetch_array( $query17, SQLSRV_FETCH_ASSOC );
	$row17 = sqlsrv_fetch_array( $query18, SQLSRV_FETCH_ASSOC );
	$row18 = sqlsrv_fetch_array( $query19, SQLSRV_FETCH_ASSOC );
	$row19 = sqlsrv_fetch_array( $query20, SQLSRV_FETCH_ASSOC );
	$row20 = sqlsrv_fetch_array( $query21, SQLSRV_FETCH_ASSOC );
	$row21 = sqlsrv_fetch_array( $query22, SQLSRV_FETCH_ASSOC );
	$row22 = sqlsrv_fetch_array( $query23, SQLSRV_FETCH_ASSOC );
	$row23 = sqlsrv_fetch_array( $query24, SQLSRV_FETCH_ASSOC );




?>



                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
           

 
 		<h5><b><u>
        ADD ROLE
        </u></b></h5>
        
         <form action="function_edit_role.php" method="post">
         				<table><tr><td>
                        			    	  	
                        <label for="RoleId">Role ID </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" value="<?php echo $result['role_id'] ?>"  disabled>   *no space
                        <input name="role_id"  type="hidden" value="<?php echo $result['role_id'] ?>"   required>
			 <script>
				document.getElementById('RoleId').onkeydown = function (event) {

 					 var key = event.keyCode || event.which; 
 
 					 if (key == 32) { //Space bar key code
  					  //Prevent default action, which is inserting space
  					  if (event.preventDefault) event.preventDefault(); //normal browsers
    				event.returnValue = false; //IE
						  }
						};
						</script>
			    		    
			    		</td>
                        </tr>
                        <td>&nbsp; </td>
                        <tr><td>
                        <label for="Description">Description </label>&nbsp;&nbsp;</td>
                        <td>
                        	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			    		    <input name="description" type="text" value="<?php echo $result['description'] ?>" style="width: 300px;" required>
                        </td>
                        </tr>
                        </table>
                        
			    		
                            
                        <br>
                        <br>
                        
        <h5><b>
        Accessible Module
        </b></h5>
         				<br>
                                                
         <h5><u>
        Service Request Order
        </u></h5>
        				                        
                        <div class="checkbox">
                        <table><tr><td>
                                    <label class="checkbox-inline">
                                    
                                    
                                    
                                     <input type="checkbox" name="sro[]" value="5" <?php if($row['stmt1'] > 0){echo 'checked'; }?>>Add SRO</td>
                                    </label>
                                   <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                     <input type="checkbox" name="sro[]" value="30" <?php if($row1['stmt2'] >0){echo 'checked'; }?>>Edit SRO</td>
                                    </label>
                                  <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                     <input type="checkbox" name="sro[]" value="48" <?php if($row2['stmt3'] > 0){echo 'checked'; }?>>View/Delete SRO</td></tr>
                                    </label>
                                    
                                </div>
                                <div class="checkbox">
                                   <tr><td> 
                                   <label>
                                        <input type="checkbox" name="sro[]" value="7" <?php if($row3['stmt4'] > 0){echo 'checked'; }?>>SRO Approval by BO </td>                                   </label>
                                </div>
                                <div class="checkbox">
                                 <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="checkbox" name="sro[]" value="8" <?php if($row4['stmt5'] > 0){echo 'checked'; }?>>SRO Approval By HTP</td></tr></table>
                                    </label>
                                </div>
                            
                            <br>
                            
        <h5><u>
        Biling
        </u></h5>
                   
                    <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="billing[]" value="21"<?php if($row5['stmt6'] > 0){echo 'checked'; }?>>Add Quotation</td></label>
                            
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="20" <?php if($row6['stmt7'] > 0){echo 'checked'; }?>>Add LOA</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="13" <?php if($row7['stmt8'] > 0){echo 'checked'; }?>>Add ATB</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="19" <?php if($row8['stmt9'] > 0){echo 'checked'; }?>>Add Invoice</td></tr></label>
                           
                           <tr><td>
                           <label class="checkbox-inline">
                           <input type="checkbox" name="billing[]" value="22" <?php if($row9['stmt10'] > 0){echo 'checked'; }?>>Update Payment</td></tr></label>
                           </table>
                           </div>         
                            <br>
                           
                           
                           
        <h5><u>
        Service Execution Order
        </u></h5>    
                           <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="seo[]" value="3" <?php if($row10['stmt11'] > 0){echo 'checked'; }?>>Add SEO</td></label>
                            
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="16" <?php if($row11['stmt12'] > 0){echo 'checked'; }?>>Edit SEO</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="24" <?php if($row12['stmt13'] > 0){echo 'checked'; }?>>View/Delete SEO</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="23" <?php if($row13['stmt14'] > 0){echo 'checked'; }?>>Update Finance Status</td></tr></label>
                           </table>
                           
                           
                           <br>
                           
        <h5><u>
        View Document
        </u></h5>  
        
        			      <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="doc" value="51" <?php if($row14['stmt15'] > 0){echo 'checked'; }?>>View All Documents</td></tr></label> 
                            </table>
                            </div>   
                            
                            <br>
                            
        <h5><u>
        Administration
        </u></h5>
        				<div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="1" <?php if($row15['stmt16'] > 0){echo 'checked'; }?>>Add Customer</td></label>
                         
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="9" <?php if($row16['stmt17'] > 0){echo 'checked'; }?>>Customer Maintenance</td></tr></label> 
                         
                        <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="34" <?php if($row17['stmt18'] > 0){echo 'checked'; }?>>Add Role</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="35" <?php if($row18['stmt19'] > 0){echo 'checked'; }?>>Role Maintenance</td></tr></label>
                                  
                         <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="6"  <?php if($row19['stmt20'] > 0){echo 'checked'; }?>>Add User</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="43" <?php if($row20['stmt21'] > 0){echo 'checked'; }?>>User Maintenance</td></tr></label> 
                         
                         <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="2" <?php if($row21['stmt22'] > 0){echo 'checked'; }?>>Add Project</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                         <input type="checkbox" name="admin[]" value="36" <?php if($row22['stmt23'] > 0){echo 'checked'; }?>>Project Maintenance</td></tr></label>
                          </table>
                          </div>
                          <br>
                         
        <h5><u>
        System Configuration
        </u></h5> 
        
        				<div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="config[]" value="52" <?php if($row23['stmt24'] > 0){echo 'checked'; }?>>Reset Password</td></tr></label>
                            </table>
                            </div>
                            
                            <br>
                            <br>
                            
                            <div style="margin-left: 250px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="Save"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                            
                            
                          
                          
                            
			    		
			      	</form>
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>
<?php
//}
//else
//{
	//header("Location:../error.php");
//}
?>
