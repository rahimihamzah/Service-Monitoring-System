<?php

include "../connection.php";

$roleid=$_POST['role_id'];
$design=$_POST['description'];
@$sro=$_POST['sro'];
@$biling=$_POST['billing'];
@$seo=$_POST['seo'];
@$doc=$_POST['doc'];
@$admin=$_POST['admin'];
@$config=$_POST['config'];
//echo $doc;
/*echo "<pre>";
print_r($sro);
print_r($biling);
print_r($seo);
//print_r($doc);
print_r($admin);
print_r($config);
echo "</pre>";
*/

$sql="update role set description='$design' where role_id='$roleid'";
$sql1="delete from task where role_id='$roleid'";
if(sqlsrv_query($conn,$sql)){
		sqlsrv_query($conn,$sql1);
	if(!empty($sro)){	

	foreach($sro as $sro2)
	{
		
		$sql2  = "INSERT INTO task (type_id ,role_id, url_id) VALUES ('1', '$roleid', '$sro2')";
		
		sqlsrv_query($conn,$sql2);
	}
	
	}
	if(!empty($biling)){	
	foreach($biling as $biling2)
	{
		
	
		$sql3="INSERT INTO task (type_id ,role_id, url_id) VALUES ('2', '$roleid', '$biling2')";
		
		sqlsrv_query($conn,$sql3);
		
	}
	}if(!empty($seo)){	
	
	foreach($seo as $seo2)
	{
		
	
		$sql4="INSERT INTO task (type_id ,role_id, url_id) VALUES ('3', '$roleid', '$seo2')";
		
		sqlsrv_query($conn,$sql4);
		
	}
	}
	
	
	if(!empty($doc)){
		$sql5="INSERT INTO task (type_id ,role_id, url_id) VALUES ('4', '$roleid', '$doc')";
		
		sqlsrv_query($conn,$sql5);
	}
	if(!empty($admin)){	
	foreach($admin as $admin2)
	{
		
	
		$sql6="INSERT INTO task (type_id ,role_id, url_id) VALUES ('5', '$roleid', '$admin2')";
		
		sqlsrv_query($conn,$sql6);
		
	}
	}
	if(!empty($config)){	
	
	foreach($config as $config2)
	{
	
		$sql7="INSERT INTO task (type_id ,role_id, url_id) VALUES ('6', '$roleid', '$config2')";
		
		sqlsrv_query($conn,$sql7);
		
	}
	
	}
echo '<script type="text/javascript">
			alert("Successfully Saved");
				window.location = "maintenance.php";
			</script>';
} else {
	if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}
	}
}
?>