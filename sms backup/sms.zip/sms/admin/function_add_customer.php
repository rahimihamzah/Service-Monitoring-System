<?php
session_start();
$user=$_SESSION['username'];
$date=date("d-m-Y");
include "../connection.php";


$cus_name =$_POST['customer_name'];
$locate =$_POST['location'];
$hodepartment =$_POST['hod'];
$emel =$_POST['email'];
$contact=$_POST['contact'];
$type=$_POST['cus_type'];



	$sql="INSERT INTO customer (customer_name, location, hod, email, contact_no, customer_type, date_created, created_by) VALUES ('$cus_name','$locate','$hodepartment','$emel','$contact','$type','$date','$user')";

	
	if(sqlsrv_query($conn,$sql))
	{
		header("Location: customer_maintenance.php");
	}
	
	else
	{
		if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}
	}
	}

?>