

<?php
//session_start();
include ("header.php");


?>



                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Add Role
                                </li>
                                <li>
                                <ii class="fa fa-edit"></i><a href="maintenance.php" > Role Maintenance </a> 
                                </li>
                                <li>
                           		<i class="fa fa-edit"></i><a href="add_user.php" > Add User </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="user_maintenance.php" > User Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_customer.php" > Add Customer </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="customer_maintenance.php" > Customer Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_project.php" > Add Project </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="project_maintenance.php" > Project Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="system_config.php" > System Configuration </a> 
                                </li>
                            
                        </ol>
            <!-- /.row -->
 
 		<h5><b><u>
        ADD ROLE
        </u></b></h5>
        
         <form action="function_add_role.php" method="post">
         				<table><tr><td>
                        			    	  	
                        <label for="RoleId">Role ID </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="role_id" id="RoleId" type="text"  required>   *no space
			 <script>
				document.getElementById('RoleId').onkeydown = function (event) {

 					 var key = event.keyCode || event.which; 
 
 					 if (key == 32) { //Space bar key code
  					  //Prevent default action, which is inserting space
  					  if (event.preventDefault) event.preventDefault(); //normal browsers
    				event.returnValue = false; //IE
						  }
						};
						</script>
			    		    
			    		</td>
                        </tr>
                        <td>&nbsp; </td>
                        <tr><td>
                        <label for="Description">Description </label>&nbsp;&nbsp;</td>
                        <td>
                        	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			    		    <input name="description" type="text" style="width: 300px;" required>
                        </td>
                        </tr>
                        </table>
                        
			    		
                            
                        <br>
                        <br>
                        
        <h5><b>
        Accessible Module
        </b></h5>
         				<br>
                                                
         <h5><u>
        Service Request Order
        </u></h5>
        				                        
                        <div class="checkbox">
                        <table><tr><td>
                                    <label class="checkbox-inline">
                                     <input type="checkbox" name="sro[]" value="5">Add SRO</td>
                                    </label>
                                   <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                    <input type="checkbox" name="sro[]" value="30">Edit SRO</td>
                                    </label>
                                  <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                     <input type="checkbox" name="sro[]" value="48">View/Delete SRO</td></tr>
                                    </label>
                                    
                                </div>
                                <div class="checkbox">
                                   <tr><td> 
                                   <label>
                                        <input type="checkbox" name="sro[]" value="7">SRO Approval by BO </td>                                   </label>
                                </div>
                                <div class="checkbox">
                                 <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="checkbox" name="sro[]" value="8">SRO Approval By HTP</td></tr></table>
                                    </label>
                                </div>
                            
                            <br>
                            
        <h5><u>
        Biling
        </u></h5>
                   
                    <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="billing[]" value="21" />Add Quotation</td></label>
                            
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="20" />Add LOA</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="13" />Add ATB</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="billing[]" value="19" />Add Invoice</td></tr></label>
                           
                           <tr><td>
                           <label class="checkbox-inline">
                           <input type="checkbox" name="billing[]" value="22" />Update Payment</td></tr></label>
                           </table>
                           </div>         
                            <br>
                           
                           
                           
        <h5><u>
        Service Execution Order
        </u></h5>    
                           <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="seo[]" value="3" />Add SEO</td></label>
                            
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="16" />Edit SEO</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="24" />View/Delete SEO</td></label>
                           <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <input type="checkbox" name="seo[]" value="23" />Update Finance Status</td></tr></label>
                           </table>
                           
                           
                           <br>
                           
        <h5><u>
        View Document
        </u></h5>  
        
        			      <div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="doc" value="51" />View All Documents</td></tr></label> 
                            </table>
                            </div>   
                            
                            <br>
                            
        <h5><u>
        Administration
        </u></h5>
        				<div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="1" />Add Customer</td></label>
                         
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="9" />Customer Maintenance</td></tr></label> 
                         
                        <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="34" />Add Role</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="35" />Role Maintenance</td></tr></label>
                                  
                         <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="6" />Add User</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <input type="checkbox" name="admin[]" value="43" />User Maintenance</td></tr></label> 
                         
                         <tr><td> 
                        <label class="checkbox-inline">
                        	<input type="checkbox" name="admin[]" value="2" />Add Project</td></label> 
                         <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                         <input type="checkbox" name="admin[]" value="36" />Project Maintenance</td></tr></label>
                          </table>
                          </div>
                          <br>
                         
        <h5><u>
        System Configuration
        </u></h5> 
        
        				<div class="checkbox">
                    <table><tr><td>
                    	<label class="checkbox-inline">
                        	<input type="checkbox" name="config[]" value="52" />Reset Password</td></tr></label>
                            </table>
                            </div>
                            
                            <br>
                            <br>
                            
                            <div style="margin-left: 250px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="Save"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                            
                            
                          
                          
                            
			    		
			      	</form>
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>
