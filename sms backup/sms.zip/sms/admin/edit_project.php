<?php
include ("header.php");
include ("../connection.php");

$strCustomerID = null;

   if(isset($_GET["project_code"]))
   {
	   $strCustomerID = $_GET["project_code"];
   
   }


 	$stmt = "SELECT * FROM project where project_code=?";
	$stmt2 = "SELECT * FROM [user]";
	$params = array($strCustomerID);

	$query = sqlsrv_query( $conn, $stmt, $params);
	$query2 = sqlsrv_query( $conn, $stmt2);
	$result= sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);
	
	


	
?>



                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            <ol class="breadcrumb">
                            	<li>
                                <i class="fa fa-edit"></i><a href="index.php" >Add Role</a>
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="maintenance.php" > Role Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_user.php" >Add User</a>
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="user_maintenance.php" > User Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"><a href="add_customer.php" ></i>Add Customer </a>
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="customer_maintenance.php" > Customer Maintenance </a> 
                                </li>
                                <li  class="active"> 
                                <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Add Project
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="project_maintenance.php" > Project Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="system_config.php" > System Configuration </a> 
                                </li>
                                
                                
                            
                            
                        </ol>
            <!-- /.row -->
 		<h5><b><u>
        ADD PROJECT
        </u></b></h5>
        <br>
 		
         				<form action="submit_edit_project.php" method="post">
         				<table>
                        <tr><td>
                        <label for="customer">Customer </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       <input style="width: 400px;" value="<?php echo $result['customer_name'];?>" disabled>                                       
                        </td>
                        </tr>
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="project_code">Project Code </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input style="width: 200px;" value="<?php echo $result['project_code'];?>" disabled>
                        <input name="project_code" type="hidden" value="<?php echo $result['project_code'];?>"  required>
					  
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="project_name">Project Name </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="project_name" type="text" style="width: 400px;" value="<?php echo $result['project_name'];?>" required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="project_manager">Project Manager </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="project_manager" type="text" style="width: 400px;" value="<?php echo $result['project_manager'];?>" required>
                        </td>
                        </tr>
                        
                        
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Email">Email</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="email" type="text" style="width: 400px;" value="<?php echo $result['email'];?>" required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="contact">Contact No</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="contact" type="text" style="width: 200px;" value="<?php echo $result['contact_no'];?>"  required>
                        </td>
                        </tr>
                        
                        
                        
                        </table>
                        <br>
                        
                        
        <h5><u>
        Add Business Owner
        </u></h5>
                        
                        
                        
                        
                        <table>                       
                        <tr><td>
                        <label for="bus_owner">Business Owner </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <select name="bo" style="width: 400px; height:27px;"  required>
						<?php echo "<option value='".$result['business_owner']."'>".$result['business_owner']."</option>";
						?>

                        	<option value=""> -Select-</option>
                            <?php
							while($row2 = sqlsrv_fetch_array($query2)){
                            echo "<option value='".$row2['user_id']."'>".$row2['user_id']."</option>";
							}
							?>
                            
                            
                         </select>                                          
                        </td>
                        </tr>
                                              
                        
                        </table>
                        
                        <br />
                         <div style="margin-left: 250px;" >
                            <table><tr><td>
                            <input type="hidden" name="project_code" value="<?php echo $result['project_code'] ?>">
   							<input class="btn btn-info" type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                            <br>
                         </form> 
                            
			    		
			      	
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



