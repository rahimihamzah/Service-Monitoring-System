 <?php 
include "../config.php";
$id_car = $_POST['id_car'];
$sql = "select * from car where id_car='$id_car'";
$result = mysqli_query ($conn, $sql);
$row = mysqli_fetch_array($result);
echo "<center><img src='../uploads1/".$row['car']."'style='width:50%'></center></br>";

echo "<p><span  aria-hidden='true'></span><b> Vehicle's Information</b></p>";
echo "<table class='table table-striped table-hover'>
	  <tr><td><b>File Number</b></td><td>".$row['file_no']."</td></tr>
	  <tr><td><b>Registration Number</b></td><td>".$row['reg_no']."</td></tr>
	  <tr><td><b>Registered Owner Name</b></td><td>".$row['reg_owner']."</td></tr>
	  <tr><td><b>Maker</b></td><td>".$row['maker']."</td></tr>
	  <tr><td><b>Model</b></td><td>".$row['model']."</td></tr>
	  <tr><td><b>Engine Ability (cc)</b></td><td>".$row['cc']."</td></tr>
	  <tr><td><b>Color</b></td><td>".$row['color']."</td></tr>
	   <tr><td><b>Manufactured Year</b></td><td>".$row['year_maker']."</td></tr>
	  <tr><td><b>Registration Date</b></td><td>".$row['reg_date']."</td></tr>
	  <tr><td><b>Expired Date of Lesen Kenderaan Motor(LKM)</b></td><td>".$row['roadtax']."</td></tr>
	  <tr><td><b>Vehicle's Insurance</b></td><td>".$row['insurans']."</td></tr>
	  <tr><td><b>Ownership Claim By</b></td><td>".$row['pro_claim']."</td></tr></table>";
?>
<body onload=javascript:print();>
