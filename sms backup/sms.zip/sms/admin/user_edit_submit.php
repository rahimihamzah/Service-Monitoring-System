<?php
  include ("../connection.php");
  $id=$_POST['user_id'];
  $name=$_POST['username'];
  $design=$_POST['designation'];
  $role=$_POST['user_role'];
  $emel=$_POST['email'];
 
  //echo $id.'<p>'.$ecategory.'<p>'.$equestion.'<p>'.$eop1.'<p>'.$eop2.'<p>'.$eop3.'<p>'.$ejawapan;
if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}
}
  $sql="UPDATE [user] SET username='$name', user_designation='$design', role_id='$role', email='$emel' WHERE user_id='$id'";
  if(sqlsrv_query($conn,$sql))
  {
  echo '<script type="text/javascript">
			alert("Successfully Saved");
				window.location = "user_maintenance.php";
			</script>';
  }
  else
  {
	    echo '<script type="text/javascript">
			alert("Ralat");
				window.location = edit_user.php";
			</script>';
  }
?>
