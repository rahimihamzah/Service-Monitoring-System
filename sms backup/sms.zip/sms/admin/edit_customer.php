<?php
include ("header.php");

include ("../connection.php");




$strCustomerID = null;

   if(isset($_GET["customer_id"]))
   {
	   $strCustomerID = $_GET["customer_id"];
   
   }


 if( $conn === false ) {
      die( print_r( sqlsrv_errors(), true));
   }

	$stmt = "SELECT * FROM customer WHERE customer_id = ? ";
	$params = array($strCustomerID);

	$query = sqlsrv_query( $conn, $stmt, $params);

	$result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);
	echo $strCustomerID;
	//}
?>

 

                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
          
            <!-- /.row -->
 		<h5><b><u>
        EDIT CUSTOMER
        </u></b></h5>
        <br>
 		
         				<form action="edit_customer1.php" method="post">
         				<table><tr><td>
                        <label for="customer_name">Customer Name </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="customer_name" type="text" style="width: 400px;" value="<?php echo $result['customer_name'] ?>" required>
			    		
                        </td>
                        </tr>
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="location">Location </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="location" type="text" style="width: 400px;" value="<?php echo $result['location'] ?>"  required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="hod">Head Of Department </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="hod" type="text" style="width: 400px;"  value="<?php echo $result['hod'] ?>"required>
                        </td>
                        </tr>
                        
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Email">Email</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="email" type="text" style="width: 400px;"  value="<?php echo $result['email'] ?>"required>
                        </td>
                        </tr>
                        
                         <td>&nbsp;</td>
                        <tr><td>
                        <label for="contact">Contact No</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="contact" type="text" style="width: 200px;" value="<?php echo $result['contact_no'] ?>" required>
                        </td>
                        </tr>
                        
                        
                                               
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="cus_type">Customer Type </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                         <?php
						if($result['customer_type'] == 1){
							$type = "Internal";
						} else{
							$type = "External";
						}
						?>
                        <select name="cus_type" style="width: 400px; height:27px;" required>
                        	<option value="<?= $result['customer_type'] ?>"><?= $type ?></option>
                            <?php
							//1: internal
							//2: external
							if($result['customer_type'] == 1) {
							?>
                            <option value="2">External</option>
							<?php } else {
							?>
                            <option value="1">Internal</option>
                            <?php } ?>
                         </select>                                          
                        </td>
                        </tr>
                                              
                        
                        </table>
                        
                        <br />
                         <div style="margin-left: 250px;" >
                            <table><tr><td> 
                            <input type="hidden" name="customer_id" value="<?php echo $result['customer_id'] ?>">
   							<input class="btn btn-info" name="update"type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="reset" value="Cancel" onClick="document.location.href='customer_maintenance.php'"></td>
                            </tr>
                            </table>
							</div>
                         </form> 
                            
			    		
			      	
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



