<!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>



<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<script>
$(function() {
   $( "#date" ).datepicker();
 });
</script>
<script>
$(function() {
   $( "#start_date" ).datepicker();
 });
</script>
<script>
$(function() {
   $( "#end_date" ).datepicker();
 });
</script>
<script>
$(function() {
   $( "#date2" ).datepicker();
 });
</script>

</head>


  
<?php
include ("header.php");
?>


                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            
            <!-- /.row -->
            <body>
 		<h5><b><u>
        SERVICE REQUEST ORDER FORM (SRO)
        </u></b></h5>
        <br>
 		
         				<form action="register_submit.php" method="post">
         				<table><tr><td>
                        <label for="date">Date </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text"  name="date" id="date" style="width: 200px;" disabled>
                        <input type="hidden"  name="date" id="date" style="width: 200px;">
			    		
                        </td>
                        </tr>
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="reference">Reference No </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="reference" type="text" style="width: 200px;" disabled>
                        <input name="reference" type="hidden" style="width: 200px;" >
                        </td>
                        </tr>
                        </table>
                        
                        
        <br>         
        <h5><b><u>
        A. TYPE OF SERVICE
        </u></b></h5>
        <br>
                        <div class="checkbox">
                        <table><tr><td>
                        	<label class="checkbox-inline">
                            <input type="checkbox" name="prr" value="" disabled>Pre-Sales / RFI / RFQ
                            <input type="hidden" name="prr" value=""></td>
                            
                            </label>
                            <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;  
                            <label class="checkbox-inline">
                            <input type="checkbox" name="ad" value="" disabled>Application Development
                            <input type="hidden" name="ad" value=""></td>
                            </label>
                            
                            <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            <label class="checkbox-inline">
                            <input type="checkbox" name="at" value="" disabled>Application Troubleshooting
                            <input type="hidden" name="at" value=""></td>
                            </label>
                            </tr>
                            
                            
                            <tr><td>
                            <label class="checkbox-inline">
                            <input type="checkbox" name="tc" value="" disabled>Technical Consultation
                            <input type="hidden" name="tc" value=""></td>
                            </label>
                            
                            <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            
                            <label class="checkbox-inline">
                            <input type="checkbox" name="testing" value="" disabled>Testing
                            <input type="hidden" name="testing" value=""></td>
                            </label>
                            
                             <td>
                             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                             
                            <label class="checkbox-inline">
                            <input type="checkbox" name="dm" value="" disabled>Data Migration
                            <input type="hidden" name="dm" value=""></td>
                            </label> 
                            </tr>
                            
                            
                            <tr><td>
                            <label class="checkbox-inline">
                            <input type="checkbox" name="poc" value="" disabled>Proof Of Concept
                            <input type="hidden" name="poc" value=""></td>
                            </label>
                            
                            <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            
                            <label class="checkbox-inline">
                            <input type="checkbox" name="qa" value="" disabled>QA
                            <input type="hidden" name="qa" value=""></td>
                            </label>
                            
                             <td>
                             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                             
                            <label class="checkbox-inline">
                            <input type="checkbox" name="pm" value="" disabled>Project Management
                            <input type="hidden" name="pm" value=""></td>
                            
                            </label> 
                            </tr>
                            </table>
                        <table>                                                
                        <tr><td>
                        <label class="checkbox-inline">
                        <input type="checkbox" name="other" value="" disabled>Other (Please Specify)
                        <input type="hidden" name="other" value=""></td>
                        </label>
                        </td>
                        
                        
                        <td>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                        <input type="text" name="other" id="other" style="width: 510px;" disabled>
                        <input type="hidden" name="other" id="other" style="width: 510px;">
                                              
                        </tr>
                        </table>
                        

<br>
   		<h5><b><u>
        B. PROJECT INFORMATION
        </u></b></h5>
        <br>     
        
        	<table><tr><td>
            <label for="customer">Customer </label></td>
            <td>     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
                  <select name="cus_type" style="width: 510px; height:27px;"  disabled>
                  <option value=""></option>
                  <option value="">Internal</option>
                  <option value="">External</option>
                            
                  </select>
                  
                      
             </td>
             
             </tr>
             
             <td>&nbsp;</td>
             <tr><td>
             <label for="project_name">Project Name </label></td>
             

             
             <td>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             
             <select name="project_name" style="width: 510px; height:27px;"  disabled>
                  <option type"hidden" value=""></option>
                  <option value="">Internal</option>
                  <option value="">External</option>
                            
                  </select>
                  <select name="project_name" style="width: 510px; height:27px; display:none">
                  <option type"hidden" value=""></option>
                  <option value="">Internal</option>
                  <option value="">External</option>
                            
                  </select>
             </td> 
             </tr>
             
             <td>&nbsp;</td>
             <tr><td>
             <label for="project_manager">Project Manager </label></td>
             
             <td>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" value="" style="width: 510px;" disabled>
            <input type="hidden" value"" name="project_manager" style="width: 510px;">
            </td>
            </tr>
            
            <td>&nbsp;</td>
            <tr><td>
            <label for="start_date">Start Date </label></td>
            <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            <input type="text" name="start_date" id="start_date" style="width: 200px;" disabled>
            <input type="hidden" name="start_date" id="start_date" style="width: 200px;">
            </td>
            </tr>
            <td>&nbsp;</td>
            <tr><td>
            <label for="end_date">End Date </label></td>
            
            <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            <input type="text" name="end_date" id="end_date" style="width: 200px;" disabled>
            <input type="hidden" name="end_date" id="end_date" style="width: 200px;">
            </td>
            </tr>
            <td>&nbsp;</td>
            
            <tr><td>
            <label for="project_site_location">Project Site Location </label></td>
                        
            <td>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" value="" style="width: 510px;" disabled>
            <input type="hidden" value"" name="project_site_location" style="width: 510px;">
            </td>
            </tr>
            
            <td>&nbsp;</td>
            <tr><td>
            <label for="wbs_code">WBS Code </label></td>
            <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" name="wbs_code" style="width: 510px;" disabled>
            <input type="hidden" value"" name="wbs_code" style="width: 510px;">
            
            </td>
            </tr>
            <td>&nbsp;</td>
            <tr><td>
            <label for="charges">Charges </label></td>
            <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           	<select name="charges" style="width: 510px; height:27px;"  disabled>
                  <option value=""></option>
                  <option value="Chargeable">Chargeable</option>
                  <option value="Non-Chargeable">Non-Chargeable</option>
                            
                  </select>
                  
                  	<select name="charges" style="width: 510px; height:27px; display:none" >
                  <option value=""></option>
                  <option value="Chargeable">Chargeable</option>
                  <option value="Non-Chargeable">Non-Chargeable</option>
                            
                  </select>
            </td>
            </tr>
            
            </table>
            
            
      <br>
      <br>
      <h5><b><u>
      C. DETAILS SERVICE(S) REQUESTED
      </u></b></h5>
        
    	  <table><td><tr>
      	  <textarea name="textarea" rows="4" cols="108" disabled>
      	  </textarea>
          <textarea style="display:none" name="textarea" rows="4" cols="108">
      	  </textarea>
          </td>
      	  </tr>
          </table>
          
      <br>
      <h5><b><u>
      C. REQUESTOR'S DETAILS
      </u></b></h5>
      
      <h5><b>
      REQUESTED BY
      </b></h5>
      <br>

      
      		<table><tr><td>
      
      
      		<label for="name">Name </label></td>
            
            <td>      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              
              
            <input type="text" id="name" style="width: 510px;" disabled>
            <input type="hidden" value"" name="name" style="width: 510px;">
            </td>
            </tr>
            
            <td>&nbsp;</td>
            <tr><td>
            <label for="designation">Designation </label></td>
            
            
            <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            
            <input type="text" id="designation" style="width: 510px;" disabled>
            <input type="hidden" value"" name="name" style="width: 510px;">
            </td>
            </tr>
            <td>&nbsp;</td>
            
            <tr><td>
            <label for="date4">Date </label></td>
            
            <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            <input type="text" name="date2" id="date2" style="width: 200px;" disabled>
            <input type="hidden" name="date2" id="date2" style="width: 200px;">
            </td>
            </tr>
            
            </table>
            
       <br>
      
      <h5><i><b>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Service Request Order Form Successfully Saved
      </b></i></h5>
                        
                        
                        
                        
                        
                        <br />
                        
                         <div style="margin-left: 265px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="Print"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                         </form> 
                            
			    		
			      	
                

</body>

</html>



