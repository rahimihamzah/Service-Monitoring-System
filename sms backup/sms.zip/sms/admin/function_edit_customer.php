<?php
  include ("../connection.php");
  $id=$_POST['customer_id'];
  $ecategory=$_POST['customer_name'];
  $equestion=$_POST['location'];
  $eop1=$_POST['hod'];
  $eop2=$_POST['email'];
  $eop3=$_POST['contact'];
  $ejawapan=$_POST['cus_type'];
 
  
  
  $updated="UPDATE customer SET customer_name='$ecategory', lcoation='$equestion', hod='$eop1', email='$eop2',contact_no='$eop3', customer_type='$ejawapan' WHERE id='$id'";
  if(sqlsrv_query($conn,$updated))
  {
  echo '<script type="text/javascript">
			alert("Successfully Saved");
				window.location = "customer_maintenance.php";
			</script>';
  }
  else
  {
	    echo '<script type="text/javascript">
			alert("Ralat");
				window.location = edit_customer.php";
			</script>';
  }
?>
