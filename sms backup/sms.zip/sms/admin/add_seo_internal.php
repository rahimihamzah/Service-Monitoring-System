<!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>



<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>


<script>
$(function() {
   $( "#date1" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#expec_start_date" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#expec_end_date" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#contract_duration" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#date_req" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#date_verify" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#date_received" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#date_approve" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#date_assign" ).datepicker();
 });
</script>



<?php
include ("header.php");
?>



			<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
             </div>
             
             
<body>
 		<h5><b><u>
        SERVICE EXECUTION ORDER FORM (SEO)
        </u></b></h5>
        <br>
        
        <form action="register_submit.php" method="post">
        <table><tr><td>
        <label for="seo_id"> SEO ID</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:200px" disabled>
        <input type="hidden" name="seo_id" style="width:200px">
        </td>
        </tr>
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="quotation_id"> Quotation ID</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:200px" disabled>
        <input type="hidden" name="quotaion_id" style="width:200px">
        </td>
        </tr>
        
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="date1"> Date</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:200px" disabled>
        <input type="hidden" name="date1" style="width:200px">
        </td>
        </tr>
        
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="customer"> Customer</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:550px" disabled>
        <input type="hidden" name="customer" style="width:550px">
        </td>
        </tr>
        
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="address"> Address</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:550px" disabled>
        <input type="hidden" name="address" style="width:550px">
        </td>
        </tr>
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="contact_person"> Contact Person</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="contact_person" style="width:550px">
        </td>
        </tr>
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="contact_no"> Contact No</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="contact_no" style="width:200px">
        </td>
        </tr>
        <td>&nbsp;</td>
        
        <tr><td>      
        <label for="total_contract_value"> Total Contract Value (RM)</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:200px" disabled>
        <input type="hidden" name="total_contract_value" style="width:200px">
        </td>
        </tr>
        
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="total_budgeted_cost"> Total Budgeted Cost (RM)</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="total_contract_cost" style="width:200px">
        
        </td>
        </tr>
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="expec_start_date"> Expected Start Date</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:200px" disabled>
        <input type="hidden" name="expec_start_date" id="expec_start_date" style="width:200px">
        </td>
        </tr>
        
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="expec_end_date"> Expected End Date</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width:200px" disabled>
        <input type="hidden" name="expec_end_date" id="expec_end_date" style="width:200px">
        </td>
        </tr>
        
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="billing_mode"> Billing Mode/Cycle<br> (Mthly/Qtrly/Yearly/Progressive)</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <textarea name="billing_mode" rows="4" cols="66">
        </textarea>
        </td>
        </tr>
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="contract_duration"> Contract Duration Period</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="contract_duration" id="contract_duration" style="width:200px">
        </td>
        </tr>
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="description_service"> Description of Service</label>
        </td>
        
        <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <textarea name="billing_mode" rows="3" cols="66" disabled>
        </textarea>
        </td>
        </tr>
        </table>
        <br>
        
        <table>
        
        <tr><td>
        <label for="scope_of_work"></label>
        </td>
        
        <td>
        	<div class="checkbox">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            	<label class="checkbox-inline">
                <input type="checkbox" value="System Integration"> System Integration
                
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Infra Devt.& Mgmt.Services"> Infra Devt.& Mgmt.Services
                </label>
                </div>
				</td>
                
                </tr>

				<tr><td>
                <label for="" type="hidden"></label>
                </td>
                
				<td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Application Development"> Application Development
                </label>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                <input type="checkbox" value="Helpdesk Services"> Helpdesk Services
                </label>
                </div>
                
                
                </td>
                </tr>
                <tr><td>
                <label for="" type="hidden"></label>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Desktop Management Services"> Desktop Management Services
                </label>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                <input type="checkbox" value="Application Maintenance"> Application Maintenance
                </label>
                </div>
                </td>
                
                
                </tr>
                
                <tr><td>
                <label for="Overall Scope of Work" type="hidden">Overall Scope of Work</label>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Network Management Services"> Network Management Services
                </label>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                <input type="checkbox" value="Hardware & Software Maintenance"> Hardware & Software Maintenance
                </label>
                </div>
                </td>
                
                
                </tr>
                
                  <tr><td>
                <label for="" type="hidden"></label>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Data Center Services"> Data Center Services
                </label>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                <input type="checkbox" value="Consultancy Service"> Consultancy Services
                </label>
                </div>
                </td>
                
                
                </tr>
                
                
                <tr><td>
                <label for="" type="hidden"></label>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Business Recovery Services"> Business Recovery Services
                </label>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                <input type="checkbox" value="Others"> Other (please specify)
                </label>
                </div>
                </td>
                
                
                </tr>
                
                <tr><td>
                <label for="" type="hidden"></label>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Internet Data Center"> Internet Data Center
                </label>
                </div>
                </td>
                </tr>
                
                  <tr><td>
                <label for="" type="hidden"></label>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="Record Management System"> Record Management System
                </label>
                </div>
                </td>
                </tr>
                
                </table>
                <br>
                
                <table>
                <tr><td>
                <label for=""></label>
                </td>
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" value="PO/LOA/Contract/Approval Letter from CEO - Mandatory"> PO/LOA/Contract/Approval Letter from CEO - Mandatory
                </label>
                
                </div>
                </td>
                </tr>
                <tr><td>
                <label for=""></label>
                </td>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;              <input type="checkbox" value="Budget/Costing Sheet Details/Cash Flow - Mandatory"> Budget/Costing Sheet Details/Cash Flow - Mandatory
                </label>
                </div>
                </td>
                </tr>
                
                <tr><td>
                <label for="support_doc"> Supporting Document <br> (Mandatory must be attached)</label>
                </td>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;              <input type="checkbox" value="New Agreement"> New Agreement
                </label>
                </div>
                </td>
                </tr>
                
                <tr><td>
                <label for=""></label>
                </td>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;              <input type="checkbox" value="Accepted Quotation/Proposal/Tender/Document to Customer - Optional"> Accepted Quotation/Proposal/Tender/Document to Customer - Optional
                </label>
                </div>
                </td>
                </tr>
                
                <tr><td>
                <label for=""></label>
                </td>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;              <input type="checkbox" value="Quotation from Vendor(s) - Optional"> Quotation from Vendor(s) - Optional
                </label>
                </div>
                </td>
                </tr>
                
                <tr><td>
                <label for=""></label>
                </td>
                
                <td>
                <div class="checkbox">
                <label class="checkbox-inline">
                				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;              <input type="checkbox" value="Existing Agreement - additional scope"> Existing Agreement - additional scope
                </label>
                </div>
                </td>
                </tr>
                
                
                </table>
                <br>
                <br>
                
                
                <table>
                <tr><td>
                <label for="requested_by"> Requested By</label>
                </td>
                
                <td>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="requested_by"  style="width:550px">
   		        </td>
                
                </tr>
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="req_design"> Designation</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="req_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="req_unit"> Unit/Dept./Division</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="req_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                <td>&nbsp;</td>
        
        <tr><td>
        <label for="date_req"> Date</label>
        </td>
        
        <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="date_req" id="date_req" style="width:200px">
        
        </td>
        </tr>
                
                </table>
                
                <br>
                <br>
                
                <table>
                <tr><td>
                <label for="verified"> Verified & Accepted By</label>
                </td>
                
                <td>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="verified"  style="width:550px">
   		        </td>
                
                </tr>
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="verify_design"> Designation</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="verify_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="ver_unit"> Unit/Dept./Division</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="ver_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                <td>&nbsp;</td>
        
        <tr><td>
        <label for="date_verify"> Date</label>
        </td>
        
        <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="date_verify" id="date_verify" style="width:200px">
        
        </td>
        </tr>
                
                </table>
                
                <br>
                <br>
                
                
                <table>
                <tr><td>
                <label for="received"> Received By</label>
                </td>
                
                <td>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="received"  style="width:550px">
   		        </td>
                
                </tr>
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="received_design"> Designation</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="received_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="received_unit"> Unit/Dept./Division</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="received_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                <td>&nbsp;</td>
        
        <tr><td>
        <label for="date_received"> Date</label>
        </td>
        
        <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="date_received" id="date_received" style="width:200px">
        
        </td>
        </tr>
                
                </table>
                <br>
                <br>
                
                <table>
                <tr><td>
                <label for="approve"> Approved By</label>
                </td>
                
                <td>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="approve"  style="width:550px">
   		        </td>
                
                </tr>
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="approve_design"> Designation</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="approve_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="approve_unit"> Unit/Dept./Division</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="approve_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                <td>&nbsp;</td>
        
        <tr><td>
        <label for="date_approve"> Date</label>
        </td>
        
        <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="date_approve" id="date_approve" style="width:200px">
        
        </td>
        </tr>
                
                </table>
                
                <br>
                <br>
                
                 <table>
                <tr><td>
                <label for="assign"> Assigned By</label>
                </td>
                
                <td>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="assign"  style="width:550px">
   		        </td>
                
                </tr>
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="assign_design"> Designation</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="assign_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                
                <td>&nbsp;</td>
                
                <tr><td>
                <label for="assign_unit"> Unit/Dept./Division</label>
                </td>
                
                <td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   		  <input type="text" name="assign_design"  style="width:550px">
                
                </td>
                
                </tr>
                
                <td>&nbsp;</td>
        
        <tr><td>
        <label for="date_assign"> Date</label>
        </td>
        
        <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="date_assign" id="date_assign" style="width:200px">
        
        </td>
        </tr>
        
        <td>&nbsp;</td>
        
        <tr><td>
        <label for="remark_assign"> Remarks</label>
        </td>
        
        <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="remark_assign" style="width:550px">
        
        </td>
        </tr>
                
                </table>
                
                
                <br>
                <br>
                
                <div style="margin-left: 300px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="Save"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                         </form> 
                         <br>
                
        
        
        
        
        
        </table>