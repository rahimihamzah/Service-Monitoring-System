<?php
include ("../connection.php");

//if(isset($_GET['customer_id']))
 // {
  $delete=$_POST['customer_id'];
  $delete="DELETE FROM customer WHERE customer_id='$delete'";
  if(sqlsrv_query($conn,$delete))
  {
	echo '<script type="text/javascript">
			alert("Succesfully Deleted");
				window.location = "customer_maintenance.php";
			</script>';
  }
  else
  {
      if( ($errors = sqlsrv_errors() ) != null) {
		foreach( $errors as $error ) {
			echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
			echo "code: ".$error[ 'code']."<br />";
			echo "message: ".$error[ 'message']."<br />";
		}}
  }
?>