 <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>


<script>
$(function() {
   $( "#date_invoice" ).datepicker();
 });
</script>

<script>
$(function() {
   $( "#date_dop" ).datepicker();
 });
</script>


<?php

include ("header.php")

?>

 <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            
            
 	<h5><b><u>
     UPDATE PAYMENT
     </u></b></h5>
     <br>
     
     
     	<form action="" enctype="multipart/form-data" method="POST">
        	
     		<table><tr><td>
            <label for="date"> Date</label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <input type="text" style="width:200px" disabled>
            <input type="hidden" name="date1" id="date_invoice" style="width:200px">
            </td>
     		</tr>
            
            <td>&nbsp;</td>
                       
            <tr><td>
            <label for="invoice_id"> Invoice ID</label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            <input type="text" style="width:200px" disabled>
            <input type="hidden" name="invoice_id" style="width:200px">
            </td>
            </tr>
            
            <td>&nbsp;</td>
            
            <tr><td>
            <label for="project_name">Project Name</label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

			<input type="text" style="width:510px" disabled>
            <input type="hidden" name="project_name" style="width:510px">
            
            </td>
            </tr>
            
            <td>&nbsp;</td>
            
            <tr><td>
            
            <label for="wbs_code">WBS Code</label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            <input type="text" style="width:200px" disabled>
            <input type="hidden" name="wbs_code" style="width:200px">
            </td>
            </tr>
            
            <td>&nbsp;</td>
            
            <tr><td>
            
            <label for="details_service_requested">Details Service Requested</label>
            </td>
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            <textarea rows="4" cols="61" disabled></textarea>
            <textarea name="details_service" rows="4" cols="61" style="display:none"></textarea>
            </td>
            </tr>
            
            <td>&nbsp;</td>
            
            <tr><td>
            <label for="start_date"> Start Date</label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <input type="text" style="width:200px" disabled>
            <input type="hidden" name="start_date" id="start_date" style="width:200px">
            </td>
            </tr>
            
             <td>&nbsp;</td>
            
            <tr><td>
            <label for="end_date"> End Date</label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <input type="text" style="width:200px" disabled>
            <input type="hidden" name="start_date" id="end_date" style="width:200px">
            </td>
            </tr>
            
            <td>&nbsp;</td>
            
            <tr><td>
            <label for="quo_amount"> Quotation Amount RM <br>
            (inc 6% GST)</br></label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			
            <input type="text" style="width:200px" disabled>
            <input type="hidden" name="quo_amount" style="width:200px">
            </td>
            </tr>
            
            <td>&nbsp;</td>
            
            <tr><td>
             <label for="date_dop"> Date of Payment</label>
            </td>
            
            <td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <input type="text" name="date_dop" id="date_dop" style="width:200px">
            </td>
     		</tr>
            
           
            
            
            </table> 
            
            <br>
            
            <div style="margin-left: 255px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
	       </div>
           <br>
           <br>
                         </form> 
            
            
            
  