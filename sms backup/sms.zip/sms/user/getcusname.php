<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["customer_name"])) {
	$query ="SELECT * FROM project WHERE project_id = '" . $_POST["customer_name"] . "'";
	$results = $db_handle->runQuery($query);
?>
	<option value="">Select State</option>
<?php
	foreach($results as $state) {
?>
	<option value="<?php echo $state["project_id"]; ?>"><?php echo $state["customer_name"]; ?></option>
<?php
	}
}
?>