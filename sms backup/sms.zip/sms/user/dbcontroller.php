<?php
//include 'connection.php';
class DBController {
	private $serverName = 'GEEZERS';
        private $connectionInfo = array('Database'=>'sms');
        
	
	
	function connectDB() {
		$conn = sqlsrv_connect($this->serverName,$this->connectionInfo);
		return $conn;
	}
	
	function selectDB($conn) {
		sqlsrv_select_db($this->connectionInfo,$conn);
	}
	
	function runQuery($query) {
         
		$results = sqlsrv_query($this->connectDB(), $query);
                
                //echo $results;
                //die();
		while($row=SQLSRV_FETCH_ARRAY($results, SQLSRV_FETCH_ASSOC)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($query) {
		$result  = sqlsrv_query($this->connectDB(),$query);
		$rowcount = sqlsrv_num_rows($result);
		return $rowcount;	
	}
}
?>