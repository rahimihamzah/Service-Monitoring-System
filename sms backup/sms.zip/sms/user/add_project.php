<?php
include ("header.php");
include ("../connection.php");

$strCustomerID = null;

   if(isset($_GET["customer_id"]))
   {
	   $strCustomerID = $_GET["customer_id"];
   
   }


 	$stmt = "SELECT * FROM customer";
	$stmt2 = "SELECT * FROM task where url_id=7";
	$params = array($strCustomerID);

	$query = sqlsrv_query( $conn, $stmt);
	$query2 = sqlsrv_query( $conn, $stmt2);
	


	
?>



                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            <ol class="breadcrumb">
                            	<li>
                                <i class="fa fa-edit"></i><a href="index.php" >Add Role</a>
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="maintenance.php" > Role Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_user.php" >Add User</a>
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="user_maintenance.php" > User Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"><a href="add_customer.php" ></i>Add Customer </a>
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="customer_maintenance.php" > Customer Maintenance </a> 
                                </li>
                                <li  class="active"> 
                                <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Add Project
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="project_maintenance.php" > Project Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="system_config.php" > System Configuration </a> 
                                </li>
                                
                                
                            
                            
                        </ol>
            <!-- /.row -->
 		<h5><b><u>
        ADD PROJECT
        </u></b></h5>
        <br>
 		
         				<form action="project_submit.php" method="post">
         				<table>
                        <tr><td>
                        <label for="customer">Customer </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <select name="customer_name" style="width: 400px; height:27px;" onclick="myFunction()" required>
                        
                        <option disabled selected value>- Select -</option>
                        	 <?php
							 
							while ($row = sqlsrv_fetch_array($query)) {
								$x=$row['customer_name'];
   							echo "<option value='$x'>" . $x . "</option>";
							}
							
							?>
                           
                            
                         </select>                                          
                        </td>
                        </tr>
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="project_code">Project Code </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="project_code" type="text" style="width: 200px;" required>
					   
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="project_name">Project Name </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="project_name" type="text" style="width: 400px;"  required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="project_manager">Project Manager </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="project_manager" type="text" style="width: 400px;"  required>
                        </td>
                        </tr>
                        
                        
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Email">Email</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="email" type="text" style="width: 400px;"  required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="contact">Contact No</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="contact" type="text" style="width: 200px;"  required>
                        </td>
                        </tr>
                        
                        
                        
                        </table>
                        <br>
                        
                        
        <h5><u>
        Add Business Owner
        </u></h5>
                        
                        
                        
                        
                        <table>                       
                        <tr><td>
                        <label for="bus_owner">Business Owner </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <select name="bus_owner" style="width: 400px; height:27px;"  required>

                        	<option disabled selected value> -Select-</option>
                            <?php
							while($row2 = sqlsrv_fetch_array($query2)){
                            echo "<option value='".$row2['role_id']."'>".$row2['role_id']."</option>";
							}
							?>
                            
                            
                         </select>                                          
                        </td>
                        </tr>
                                              
                        
                        </table>
                        
                        <br />
                         <div style="margin-left: 250px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                         </form> 
                            
			    		
			      	
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



