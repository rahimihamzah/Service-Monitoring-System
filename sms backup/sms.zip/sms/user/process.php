<?php
include '../connection.php';

$id = $_POST['id'];


//$stmt = "SELECT location from customer a left join project on b.customer_name = a.customer_name where customer_name = ?";
$stmt = "SELECT * FROM project where customer_name = ?";
$params = array($id);
$query = sqlsrv_query($conn, $stmt, $params);
?>
<option disabled selected value> - Select -</option>
<?php
while ($row = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC)) {
    $id_db = $row['project_id'];
    $project_name = $row['project_name'];
    ?>

    <option value="<?php echo $id_db ?>"><?= $project_name ?></option>
    
    
    <?php
}
?>