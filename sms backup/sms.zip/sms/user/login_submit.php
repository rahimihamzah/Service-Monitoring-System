<?php include '../config.php';

$user = $_POST['user_admin'];
$pass = $_POST['user_pass'];

//cek connection
$sql = mysqli_query ($conn, "select * from admin where admin_user='$user' and admin_pass='$pass'");
$cek= mysqli_num_rows($sql);
if ($cek>0)
{
	header ("Location:index.php");	
	
	//session value
	$user_id=$cek['user_id'];
	$_SESSION["user_id"] = $user_id;
	$user_id2 = $_SESSION["user_id"];
	die($user_id2);
}
else
{
header ("Location:../index.php");
}

?>
 