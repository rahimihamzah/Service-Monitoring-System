<?php
include '../connection.php';

$id = $_POST['id'];


//$stmt = "SELECT location from customer a left join project on b.customer_name = a.customer_name where customer_name = ?";
$stmt = "SELECT * FROM customer where customer_name = ?";
$params = array($id);
$query = sqlsrv_query($conn, $stmt, $params);
$row = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);
$loc=$row['location'];

echo json_encode($loc); 
?>