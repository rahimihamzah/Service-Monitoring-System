<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Service Monitoring System</title>


        <!-- Bootstrap Core CSS -->
        <link href="bootstrap/bootstrap/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

        <!-- Timeline CSS -->
        <link href="bootstrap/bootstrap/dist/css/timeline.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="bootstrap/bootstrap/dist/css/sb-admin-2.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="bootstrap/bootstrap/bower_components/morrisjs/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="bootstrap/bootstrap/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <?php
        include "../connection.php";
        session_start();
        $CurrentID = $_SESSION['username'];
        $CurrentID = strtoupper($CurrentID);
        
        $sq="SELECT * from [user] where user_id=?";
        $param=array($CurrentID);
        $option = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
        $kueri=sqlsrv_query($conn,$sq, $param, $option);
        $res_kueri=sqlsrv_fetch_array($kueri, SQLSRV_FETCH_ASSOC);
        $rol=$res_kueri['role_id'];
        $uname=$res_kueri['username'];
      

        $sql = "SELECT * FROM task WHERE role_id=? and type_id='1'";
        $sql1 = "SELECT * FROM task WHERE role_id=? and type_id='2'";
        $sql22 = "SELECT * FROM task WHERE role_id=? and type_id='3'";
        $sql23 = "SELECT * FROM task WHERE role_id=? and type_id='5'";
        $sql44 = "SELECT * FROM task WHERE role_id=? and type_id='6'";
        $sql55 = "SELECT * FROM task WHERE role_id=? and type_id='4'";
        
        
        //$sql2 = "SELECT * FROM url";
        $params = array($rol);
       
        //$params2 = array($CurrentID);
        $options = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
        
        //$options2 = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
        $query = sqlsrv_query($conn, $sql, $params, $options);
        $query1 = sqlsrv_query($conn, $sql1, $params, $options);
        $query2 = sqlsrv_query($conn, $sql22, $params, $options);
        $query3 = sqlsrv_query($conn, $sql23, $params, $options);
        $query4 = sqlsrv_query($conn, $sql44, $params, $options);
        $query5 = sqlsrv_query($conn, $sql55, $params, $options);
        
        $cek0=sqlsrv_num_rows($query);
        $cek1=sqlsrv_num_rows($query1);
        $cek2=sqlsrv_num_rows($query2);
        $cek3=sqlsrv_num_rows($query3);
        $cek4=sqlsrv_num_rows($query5);
        

        
        //$query2 = sqlsrv_query($conn, $sql2, $params2, $options);
        
        /*
        if ($query) {
//            echo "1";
            while ($result = sqlsrv_fetch_array($query, SQLSRV_FETCH_NUMERIC)) { //LOPPING FOR SRO
                $url_id_f = $result[3]; //get url_id
                echo $url_id_f.", ";
            }
        } else {
//            echo "2";
        }
         * 
         */
        ?>
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand" href="home.php"><p><img src="../img/logo.png" alt="Logo Heitech" style="height:30px;"><h5><i>HeiTech</h5></a>
            </div>
                
                 <ul class="nav navbar-top-links navbar-right">
                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <?php echo $uname;?><i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                 </ul>
            

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <?php if($cek0>0){ ?>
                        <li>
                            <a href="javascript:;" data-toggle="collapse" data-target="#sro"><i class="fa fa-circle-o-notch"></i> SRO <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="sro" class="collapse">   

                                <?php
                                while ($result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC)) { //LOPPING FOR SRO
                                    //$url_id_f = $result[3]; //get url_id
                                    if ($result['url_id'] == '5') {

                                        echo "<p><a href='add_sro.php'><i class='fa fa-plus-square-o' aria-hidden='true'></i> Add New SRO</a></p> ";
                                    }

                                    if ($result['url_id'] == '30') {

                                        echo '<p><a href="edit_sro.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Service Request Order</a></p> ';
                                    }

                                    if ($result['url_id'] == '48') {

                                        echo '<p><a href="view_sro.php"><i class="fa fa-list" aria-hidden="true"></i> View/Delete SRO</a></p> ';
                                    }

                                    if ($result['url_id'] == '7') {

                                        echo '<p><a href="approval_cbw.php"><i class="fa fa-check-circle" aria-hidden="true"></i> Approval by Client Business Owner</a></p> ';
                                    }


                                    if ($result['url_id'] == '8') {

                                        echo '<p><a href="approval_his.php"><i class="fa fa-check-circle" aria-hidden="true"></i> Approval by HIS</a></p> ';
                                    }
                                    //return 0;
                                }
//echo "</ul> </li>"; // END FOR SRO
                                ?>
                            </ul>
                        </li>

                        <?php } if($cek1>0){ ?>
                        <li>
                            <a href="javascript:;" data-toggle="collapse" data-target="#billing"><i class="fa fa-circle-o-notch"></i> Billing <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="billing" class="collapse">

                                <?php 
                                //$query = sqlsrv_query($conn, $sql1, $params, $options);
                                //if ($query) {
                                   // while ($row = sqlsrv_fetch_array($query)) {
                                       // $x = $row['url_id'];
                              while ($result11 = sqlsrv_fetch_array($query1, SQLSRV_FETCH_ASSOC)) { //LOPPING FOR ADMINISTRATION
//                                    if ($x == '34') {
                                        //$url_id_f2 = $result[3]; //get url_id
                                        //if ($x == '21') {
                                  if ($result11['url_id'] == '21') {
                                            
                                            echo '<p><a href="dis_quotation.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Quotation</a></p>';
                                  }
                                           
//                                        } else {
//                                            
//                                        }
                                        if ($result11['url_id'] == '20') {
//                                            
                                            
                                            echo '<p><a href="dis_loa.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload LOA</a></p>';
                                        }      
//                                        } else {
//                                            
//                                        }
                                   if ($result11['url_id']== '13') {
//
                                       echo '<p><a href="dis_atb.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Advice To Bill</a></p> ';
                                    }
//
                                    if ($result11['url_id'] == '19') {
//
                                        echo '<p><a href="dis_invoice.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Invoice</a></p> ';
                                    }
//
                                    if ($result11['url_id'] == '22') {

                                        echo '<p><a href="dis_update_payment.php"><i class="fa fa-pencil" aria-hidden="true"></i> Update Payment</a></p> ';
                                        }
                                 //   }
                               // } else {
                                       
                               
                              }
//echo "</ul> </li>"; //END FOR BILLING
                                ?>

                            </ul>
                        </li>     
                        <?php } if($cek2>0){ ?>
                        <li>
                            <a href="javascript:;" data-toggle="collapse" data-target="#seo"><i class="fa fa-circle-o-notch"></i> SEO <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="seo" class="collapse">
                                <?php
                                while ($result22 = sqlsrv_fetch_array($query2, SQLSRV_FETCH_ASSOC)) { //LOPPING FOR SEO
                                    if ($result22['url_id'] == '3') {

                                        echo '<p><a href="dis_seo.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add New SEO</a></p> ';
                                    }

                                    if ($result22['url_id'] == '16') {

                                        echo '<p><a href="dis_edit_seo.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit SEO</a></p> ';
                                    }

                                    if ($result22['url_id'] == '24') {

                                        echo '<p><a href="dis_view_seo.php"><i class="fa fa-list" aria-hidden="true"></i> View/Delete SEO</a></p> ';
                                    }

                                    if ($result22['url_id'] == '23') {

                                        echo '<p><a href="dis_update_seo_status.php"><i class="fa fa-pencil" aria-hidden="true"></i> Update SEO Status</a></p> ';
                                    }
                                }
//echo "</ul> </li>"; //END FOR BILLING
                                ?>
                                
                            </ul></li>
                            <?php } if($cek4>0){ ?>
                            <li>
                            <a href="view_doc.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> View All Documents</a>
                            
                            
                            
                            </li>
                            <?php } if($cek3>0){ ?>
                        <li>
                            <a href="javascript:;" data-toggle="collapse" data-target="#admin"><i class="fa fa-circle-o-notch"></i> Administration <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="admin" class="collapse">



                                <?php
                                while ($result33 = sqlsrv_fetch_array($query3, SQLSRV_FETCH_ASSOC)) { //LOPPING FOR ADMINISTRATION
                                    if ($result33['url_id'] == '34') {

                                        echo '<p><a href="index.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add Role</a></p> ';
                                    }

                                    if ($result33['url_id'] == '35') {

                                        echo '<p><a href="maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Role Maintenance</a></p> ';
                                    }

                                    if ($result33['url_id'] == '6') {

                                        echo '<p><a href="add_user.php"><i class="glyphicon glyphicon-user" aria-hidden="true"></i> Add User</a></p> ';
                                    }

                                    if ($result33['url_id'] == '43') {

                                        echo '<p><a href="user_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> User Maintenance</a></p> ';
                                    }

                                    if ($result33['url_id'] == '1') {

                                        echo '<p><a href="add_customer.php"><i class="fa fa-users" aria-hidden="true"></i> Add Customer</a></p> ';
                                    }

                                    if ($result33['url_id'] == '9') {

                                        echo '<p><a href="customer_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Customer Maintenance</a></p> ';
                                    }

                                    if ($result33['url_id'] == '2') {

                                        echo '<p><a href="add_project.php"><i class="fa fa-plus" aria-hidden="true"></i> Add Project</a></p> ';
                                    }

                                    if ($result33['url_id'] == '36') {

                                        echo '<p><a href="project_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Project Maintenance</a></p> ';
                                    }
                                    $result44=sqlsrv_fetch_array($query4,SQLSRV_FETCH_ASSOC);
                                    if ($result44['url_id'] == '52') {

                                        echo '<p><a href="system_config.php"><i class="fa fa-cog" aria-hidden="true"></i> System Configuration</a></p> ';
                                    }
                                    
                                }
                            }

//echo "</ul> </li>"; //END FOR ADMINISTRATION
                                ?>
                            </ul>
                        </li>
                    
                        
                    </ul>
                </div>
            </div>

            <!-- /.navbar-static-side -->
        </nav>    
    </div>


    <?php
//$url_file = basename($_SERVER['REQUEST_URL'],'?'.$SERVER['QUERY_STRING']); /* Returns The Current PHP File Name */
//echo $url_file;
    //die();
//dapatkan user_id punya session 
    /*
      $user_id2 = $_SESSION["username"];
      //$role_id=$_SESSION['role_id'];
      //echo $user_id2;


      $basename = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
      echo $basename;


      $CurrentUserID = $_SESSION['username']; //why not put this session inside the checkLogin.php?
      echo $CurrentUserID;

      //
      //die($CurrentUserID.":".$basename);
      //
      //check if user is allowed to view the page
      $allowed_status = 1;

      //echo $check_permission;


      $check_permission = "SELECT * FROM task WHERE user_id = :user_id and url_id = :url_id";
      $params = array();
      $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
      $query_a = sqlsrv_query($conn, $check_permission, $params, $options);
      $result0 = sqlsrv_fetch_array($query_a, SQLSRV_FETCH_ASSOC);
      if ($query_a === false) {
      if (($errors = sqlsrv_errors() ) != null) {
      foreach ($errors as $error) {
      echo "SQLSTATE: " . $error['SQLSTATE'] . "<br />";
      echo "code: " . $error['code'] . "<br />";
      echo "message: " . $error['message'] . "<br />";
      }
      }
      }

      echo $result0;
      die();



      //$check_permission->bindParam(':id_users', $CurrentUserID);
      //$check_permission->bindParam(':file_name', $basename);
      //$check_permission->bindParam(':permission', $allowed_status);
      //$check_permission->execute();
      //$check_permission2 = $check_permission->fetch();
      if(!$check_permission2){
      //if no permission, send to error page
      //but, if user click Home button, let him go to Dashboard page
      if($basename != "dashboard.php"){
      header("location:error.php");
      }
      }



      //$sql_a="SELECT * FROM [user] where user_id=?";
      //$params_a = array($user_id2);
      //$options_a = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
      //$query_a = sqlsrv_query($conn, $sql_a, $params_a, $options_a);
      //$result_a = sqlsrv_fetch_array($query_a, SQLSRV_FETCH_ASSOC);
      //$role_id = $result_a['role_id'];
      //echo $role_id;
      //print_r($_SESSION);
      //die();





      //$user_id3 = $_SESSION["user_id"];
      //die($url_file.":1:".$user_id2.":2:".$user_id3);

      //cek 2 parameters ni dlm table; user_task
      //kalau wujud, benarkan view page ni, kalo xde, redirect ke page error
      /*$sql = "SELECT a.*, b.*, c.* FROM [user] a left join task b on b.user_id = a.id_admin left join url c on c.url_id = b.url_id where b.user_id = '$user_id2' and c.link = '$url_file'";

      $params = array();
      $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );

      $stmt = sqlsrv_query( $conn, $sql , $params, $options );

      //cek kalau query salah
      if ($stmt === false){
      //echo "a";
      //die("Please check the query");
      } else{
      //echo "b";

      //kire bilangan rekod
      $row_count = sqlsrv_num_rows($stmt);
      echo $row_count;
      die($url_file.":".$row_count);



      if ($row_count<1)
      {
      header("Location: ../authorized.php");

      }
      else
      {
      echo "azizi";
      }
      }
     * 
     */
    /*
      $stmt0 = "SELECT a.*, b.* FROM task a left join url b on b.url_id = a.url_id WHERE a.role_id = ? and b.link = ? and a.user_id = ?";
      //echo $role_id."<p>".$url_file."<p>".$user_id2;
      //die();
      $params0 = array($role_id, $url_file, $user_id2);
      $options = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
      $query0 = sqlsrv_query($conn, $stmt0, $params0, $options);
      $result0 = sqlsrv_fetch_array($query0, SQLSRV_FETCH_ASSOC);

      //die($strCustomerID.":".$url_file.":".$session_admin);

      if ($query0 === false) {
      if (($errors = sqlsrv_errors() ) != null) {
      foreach ($errors as $error) {
      echo "SQLSTATE: " . $error['SQLSTATE'] . "<br />";
      echo "code: " . $error['code'] . "<br />";
      echo "message: " . $error['message'] . "<br />";
      }
      }
      } else {
      $row_count = sqlsrv_num_rows($query0);
      if ($row_count > 0) {
      //echo "has data";
      header("Location: home.php");

     *
     * 
     */
    ?>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>




    <!-- /.navbar-header -->


    <!-- /.navbar-top-links -->

    <!--


<li>
        <a href="javascript:;" data-toggle="collapse" data-target="#sro"><i class="fa fa-circle-o-notch"></i> SRO <i class="fa fa-fw fa-caret-down"></i></a>
        <ul id="sro" class="collapse">



          <p><a href="add_sro.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add New SRO</a></p>
        
          <p><a href="edit_sro.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Service Request Order</a></p>
                                
          <p><a href="view_sro.php"><i class="fa fa-list" aria-hidden="true"></i> View/Delete SRO</a></p>
                                
          <p><a href="approval_cbw.php"><i class="fa fa-check-circle" aria-hidden="true"></i> Approval by Client Business Owner</a></p>
          
          <p><a href="approval_his.php"><i class="fa fa-check-circle" aria-hidden="true"></i> Approval by HIS</a></p>
          </ul>
        
  </li>
  
   <li>
        <a href="javascript:;" data-toggle="collapse" data-target="#biling"><i class="fa fa-circle-o-notch"></i> Billing <i class="fa fa-fw fa-caret-down"></i></a>
        <ul id="biling" class="collapse">



          <p><a href="dis_quotation.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Quotation</a></p>
        
          <p><a href="dis_loa.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload LOA</a></p>
                                
          <p><a href="dis_atb.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Advice To Bill</a></p>
                                
          <p><a href="dis_invoice.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload Invoice</a></p>
          
          <p><a href="dis_update_payment.php"><i class="fa fa-pencil" aria-hidden="true"></i> Update Payment</a></p>
          </ul>
        
        
        
        
  </li>
  
  <li>
        <a href="javascript:;" data-toggle="collapse" data-target="#seo"><i class="fa fa-circle-o-notch"></i> SEO <i class="fa fa-fw fa-caret-down"></i></a>
  
      <ul id="seo" class="collapse">
        
        <p><a href="dis_seo.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add New SEO</a></p>
        
          <p><a href="dis_edit_seo.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit SEO</a></p>
                                
          <p><a href="dis_view_seo.php"><i class="fa fa-list" aria-hidden="true"></i> View/Delete SEO</a></p>
                                
          <p><a href="dis_update_seo_status.php"><i class="fa fa-pencil" aria-hidden="true"></i> Update SEO Status</a></p>
          
          </ul>
          </li>
                                 
         
  
        

<li>
        <a href="javascript:;" data-toggle="collapse" data-target="#admin"><i class="fa fa-circle-o-notch"></i> Admin <i class="fa fa-fw fa-caret-down"></i></a>
        <ul id="admin" class="collapse">



          <p><a href="index.php"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add Role</a></p>
        
          <p><a href="maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Role Maintenance</a></p>
                                
          <p><a href="add_user.php"><i class="glyphicon glyphicon-user" aria-hidden="true"></i> Add User</a></p>
                                
          <p><a href="user_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> User Maintenance</a></p>
        
          <p><a href="add_customer.php"><i class="fa fa-users" aria-hidden="true"></i> Add Customer</a></p>
        
          <p><a href="customer_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Customer Maintenance</a></p>
        
          <p><a href="add_project.php"><i class="fa fa-plus" aria-hidden="true"></i> Add Project</a></p>
        
          <p><a href="project_maintenance.php"><i class="fa fa-list-alt fa-fw"></i> Project Maintenance</a></p>
        
          <p><a href="system_config.php"><i class="fa fa-cog" aria-hidden="true"></i> System Configuration</a></p>
        
          <p><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Log Out</a></p>
        
        
       </li>

    -->
