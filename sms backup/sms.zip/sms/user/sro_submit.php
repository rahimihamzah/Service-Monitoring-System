<?php
session_start();
$user=$_SESSION['username'];
$date=date("Y-m-d");
include "../connection.php";

$date_a = $_POST['date'];
$reff = $_POST['reference'];
@$tos = $_POST['tos'];
$other = $_POST['other'];
$cus_type = $_POST['cus_type'];
$proj = $_POST['project_name'];
$proj_man = $_POST['project_manager'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$location = $_POST['location'];
$charges = $_POST['charges'];
$dsr = $_POST['dsr'];
$name = $_POST['name'];
$designation = $_POST['designation'];
$date2 = $_POST['date2'];



$sql = "INSERT INTO sro values (sro_id, date, type_service, customer, project_name, start_date, end_date, location, wbs_code, charges, details_services, added_by, date_added) VALUES ('$date_a', '$reff', '$tos', '$other', '$cus_type', '$proj', '$proj_man', '$start_date', '$end_date', '$location', '$charges', '$dsr', '$name', '$designation', '$date2')";









?>