<?php
include ("header.php");

?>



                    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="page-header">Service Monitoring System</h3>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            <ol class="breadcrumb">
                            	<li>
                                <i class="fa fa-edit"></i><a href="index.php" >Add Role</a>
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="maintenance.php" > Role Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_user.php" >Add User</a>
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="user_maintenance.php" > User Maintenance </a> 
                                </li>
                                <li class="active">
                                <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Add Customer 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="customer_maintenance.php" > Customer Maintenance </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="add_project.php" > Add Project </a> 
                                </li>
                                <li> 
                                <i class="fa fa-edit"></i><a href="project_maintenance.php" > Project Maintenance </a> 
                                </li>
                                <li>
                                <i class="fa fa-edit"></i><a href="system_config.php" > System Configuration </a> 
                                </li>
                                
                                
                            
                            
                        </ol>
            <!-- /.row -->
 		<h5><b><u>
        ADD CUSTOMER
        </u></b></h5>
        <br>
 		
         				<form action="function_add_customer.php" method="post">
         				<table><tr><td>
                        <label for="customer_name">Customer Name </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="customer_name" type="text" style="width: 400px;" required>
			    		
                        </td>
                        </tr>
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="location">Location </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="location" type="text" style="width: 400px;"  required>
                        </td>
                        </tr>
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="hod">Head Of Department </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="hod" type="text" style="width: 400px;"  required>
                        </td>
                        </tr>
                        
                        
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="Email">Email</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="email" type="text" style="width: 400px;"  required>
                        </td>
                        </tr>
                        
                         <td>&nbsp;</td>
                        <tr><td>
                        <label for="contact">Contact No</label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="contact" type="text" style="width: 200px;"  required>
                        </td>
                        </tr>
                        
                        
                                               
                        <td>&nbsp;</td>
                        <tr><td>
                        <label for="cus_type">Customer Type </label>&nbsp;&nbsp;</td>
                        <td> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <select name="cus_type" style="width: 400px; height:27px;"  required>
                        	<option value=""></option>
                            <option value="1">Internal</option>
                            <option value="2">External</option>
                            
                         </select>                                          
                        </td>
                        </tr>
                                              
                        
                        </table>
                        
                        <br />
                         <div style="margin-left: 250px;" >
                            <table><tr><td>
   							<input class="btn btn-info" type="submit" value="OK"></td>
                            <td>&nbsp;
                            <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                            </table>
							</div>
                         </form> 
                            
			    		
			      	
                <!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>

</body>

</html>



