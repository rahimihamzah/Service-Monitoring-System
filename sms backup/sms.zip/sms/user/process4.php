<?php
include '../connection.php';

$id = $_POST['id'];


//$stmt = "SELECT location from customer a left join project on b.customer_name = a.customer_name where customer_name = ?";
$stmt = "SELECT * FROM project where project_id = ?";
$params = array($id);
$query = sqlsrv_query($conn, $stmt, $params);
$row = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);
$loc=$row['project_code'];

echo json_encode($loc); 
?>