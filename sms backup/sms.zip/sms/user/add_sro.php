

<?php
include '../connection.php';
include ("header.php");

//session_start();
$user_id = $_SESSION['username'];
//echo $user_id;
//die();

$sqlx = "select * from [user] where user_id='$user_id'";
//echo $sqlx;
//die();
$paramx = array($user_id);
$resultx = sqlsrv_query($conn, $sqlx, $paramx);
$row77 = sqlsrv_fetch_array($resultx, SQLSRV_FETCH_ASSOC);

$sqli = "SELECT distinct customer_name from project";
$result2 = sqlsrv_query($conn, $sqli);
$sqlii = "SELECT * from project";
$result3 = sqlsrv_query($conn, $sqlii);
?>

<!-- jQuery -->
<script src="bootstrap/bootstrap/bower_components/jquery/dist/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="bootstrap/bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="bootstrap/bootstrap/bower_components/metisMenu/dist/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="bootstrap/bootstrap/bower_components/raphael/raphael-min.js"></script>
<script src="bootstrap/bootstrap/bower_components/morrisjs/morris.min.js"></script>
<script src="bootstrap/bootstrap/js/morris-data.js"></script>

<!-- Custom Theme JavaScript -->
<script src="bootstrap/bootstrap/dist/js/sb-admin-2.js"></script>



<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

        <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
        
        
        <script>
            $(function () {
                $('#date').datepicker({minDate: new Date()});
            });


        </script>
        <script>
            $(function () {
                $("#start_date").datepicker({minDate: new Date()});
            });
        </script>
        <script>
            $(function () {
                $("#end_date").datepicker({minDate: new Date()});
            });
        </script>
        <script>
            $(function () {
                $("#date2").datepicker();
            });
        </script>

    </head>




    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-6">
                <h3 class="page-header">Service Monitoring System</h3>
            </div>

            <!-- /.col-lg-12 -->
        </div>









        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-chevron-circle-right"></i> Add SRO
            </li>
            <li>
                <i class="fa fa-edit"></i><a href="edit_sro.php" > Edit Service Request Order </a> 
            </li>
            <li> 
                <i class="fa fa-edit" aria-hidden="true"></i><a href="view_sro.php" > View/Delete SRO</a>
            </li>
            <li> 
                <i class="fa fa-edit"></i><a href="approval_cbw.php" > Approval by Client Business Owner </a> 
            </li>
            <li> 
                <i class="fa fa-edit"></i><a href="approval_his.php" > Approval by HIS </a> 
            </li>


        </ol>
        <!-- /.row -->
        <body>
            <h5><b><u>
                        SERVICE REQUEST ORDER FORM (SRO)
                    </u></b></h5>
            <br>

            <form action="sro_submit.php" method="post">
                <table><tr><td>
                            <label for="date">Date </label>&nbsp;&nbsp;</td>
                        <td> 
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="text"  name="date" id="date" value="<?php echo date("d/m/Y") ?>" style="width: 200px;" disabled>
                            <input type="hidden"  name="date" id="date" value="<?php echo date("d/m/Y") ?>" style="width: 200px;" disabled>

                        </td>
                    </tr>
                    <td>&nbsp;</td>
                    <tr><td>
                            <label for="reference">Reference No </label>&nbsp;&nbsp;</td>
                        
                        <td>
                            
                            
                            
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <input name="reference" type="text" value="<?php echo "HTP2016110".substr(str_shuffle(str_repeat('1234567890', mt_rand(4,10))),1,4);
?>" style="width: 200px;"  disabled>
                            
                           
                        
                        
                        </td>
                    </tr>
                </table>


                <br>         
                <h5><b><u>
                            A. TYPE OF SERVICE
                        </u></b></h5>
                <br>
                <div class="checkbox">
                    <table><tr><td>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Pre-Sales / RFI / RFQ">Pre-Sales / RFI / RFQ</td>

                                </label>
                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;  
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Application Development">Application Development</td>
                                </label>

                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Application Troubleshooting">Application Troubleshooting</td>
                                </label>
                        </tr>


                        <tr><td>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Technical Consultation">Technical Consultation</td>
                                </label>

                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Testing">Testing</td>
                                </label>

                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Data Migration">Data Migration</td>
                                </label> 
                        </tr>


                        <tr><td>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Proof of Concept">Proof Of Concept</td>
                                </label>

                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="QA">QA</td>
                                </label>

                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                <label class="checkbox-inline">
                                    <input type="checkbox" name="tos[]" value="Project Management">Project Management</td>
                                </label> 
                        </tr>
                    </table>
                    <table>                                                
                        <tr><td>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="Other" onclick="enableDisable(this.checked, 'other')">Other (Please Specify)
                                    </td>
                                    <td>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                        <input type="text" name="other" id="other" style="width: 510px;" disabled>
                                        <script language="javascript">
                                            function enableDisable(bEnable, other)
                                            {
                                                document.getElementById(other).disabled = !bEnable
                                            }
                                        </script>                     
                                        </tr>
                                        </table>


                                        <br>
                                        <h5><b><u>
                                                    B. PROJECT INFORMATION
                                                </u></b></h5>
                                        <br>     

                                        <table>
                                            <tr>
                                                <td>
                                                    <label for="customer">Customer </label></td>
                                                <div alignid="result_circuit" ></div>
                                                <td>     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    
                                                    <select name="cus_type" id="cus_type" style="width: 510px; height:27px;" required>
                                                        <option disabled selected value> - Select -</option>
                                                        <?php
                                                        while ($row_cus = sqlsrv_fetch_array($result2)) {
                                                            echo "<option value='" . $row_cus['customer_name'] . "'>" . $row_cus['customer_name'] . "</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </td>
                                            </tr>

                                            <script>
                                                function select_cir(id) {
                                                    $.ajax(
                                                            {
                                                        type: "POST",
                                                        data: {id: id},
                                                        url: "process.php",
                                                        success: function (res2) {
                                                            $("#result_circuit");
                                                            $('#project_name').append(res2)
                                                        }
                                                    });
                                                }

                                                $("#cus_type").on("change", function () {
                                                    var id = $(this).val();
                                                    //alert(id);
                                                   
                                                    document.getElementById("project_name").options.length = 0;
                                                    
                                                    select_cir(id);
                                                  
                                                });
                                                
                                                
                                                
                                            </script>

                                            <td>&nbsp;</td>
                                            <tr>
                                                <td>
                                                    
                                                    
                                                    <label for="project_name">Project Name </label></td>
                                                <td>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                                    <select name="project_name" id="project_name" style="width: 510px; height:27px;"  required>
                                                        <option disabled selected value> - Select -</option>
                                                    </select>   
                                                </td> 
                                            </tr>
                                            
                                           

                                            <!-- jQuery Libraries required -->
                                <script>
                                $("#project_name").on("change", function () { 
                                        var selected = $(this).val(); 

                                        $.post('process3.php', {id: selected }, function (response) { 
                                                var result1 = $.parseJSON(response); 
                                                document.getElementById("project_manager").value = result1; 
                                        }); 
                                }); 
                            </script>

                                            
                                            
                                            <td>&nbsp;</td>
                                            <tr><td>
                                                    <label for="project_manager">Project Manager </label></td>

                                                <td>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <input type="text" id="project_manager" value="" style="width: 510px;" disabled>
                                                    <input type="hidden" name="project_manager" id="project_manager" value="" style="width: 510px;">
                                                </td>
                                            </tr>
                             
                                            <td>&nbsp;</td>
                                            <tr><td>
                                                    <label for="start_date">Start Date </label></td>
                                                <td>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                                    <input type="text" name="start_date" id="start_date" style="width: 200px;" required>
                                                </td>
                                            </tr>
                                            <td>&nbsp;</td>
                                            <tr><td>
                                                    <label for="end_date">End Date </label></td>

                                                <td>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                                    <input type="text" name="end_date" id="end_date" style="width: 200px;" required>
                                                </td>
                                            </tr>
                                            <td>&nbsp;</td>
<script>
                                $("#cus_type").on("change", function () { 
                                        var selected = $(this).val(); 

                                        $.post('process2.php', {id: selected }, function (response) { 
                                                var result = $.parseJSON(response); 
                                                document.getElementById("location").value = result; 
                                        }); 
                                }); 
                            </script>
                                            <tr><td>
                                                    <label for="project_site_location">Project Site Location </label></td>

                                                <td>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <input type="text" id="location" value="" style="width: 510px;" disabled>
                                                    <input type="hidden" name="location" id="location" value="" style="width: 510px;">
                                                </td>
                                            </tr>
<script>
                                $("#project_name").on("change", function () { 
                                        var selected = $(this).val(); 

                                        $.post('process4.php', {id: selected }, function (response) { 
                                                var result1 = $.parseJSON(response); 
                                                document.getElementById("wbs").value = result1; 
                                        }); 
                                }); 
                            </script>
                                            <td>&nbsp;</td>
                                            <tr><td>
                                                    <label for="wbs_code">WBS Code </label></td>
                                                <td>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <input type="text" id="wbs" style="width: 510px;" disabled>
                                                    <input type="hidden" name="wbs" id="wbs" style="width: 510px;">

                                                </td>
                                            </tr>

                                            <td>&nbsp;</td>
                                            <tr><td>
                                                    <label for="charges">Charges </label></td>
                                                <td>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <select name="charges" style="width: 510px; height:27px;"  required>
                                                        <option disabled selected value> - Select -</option>
                                                        <option value="Chargeable">Chargeable</option>
                                                        <option value="Non-Chargeable">Non-Chargeable</option>

                                                    </select>
                                                </td>
                                            </tr>

                                        </table>


                                        <br>
                                        <br>
                                        <h5><b><u>
                                                    C. DETAILS SERVICE(S) REQUESTED
                                                </u></b></h5>

                                        <table><td><tr>
                                            <textarea name="dsr" rows="4" cols="108">
                                            </textarea></td>
                        </tr>
                    </table>

                    <br>
                    <h5><b><u>
                                C. REQUESTOR'S DETAILS
                            </u></b></h5>

                    <h5><b>
                            REQUESTED BY
                        </b></h5>
                    <br>

                    <table><tr><td>


                                <label for="name">Name </label></td>

                            <td>      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


                                <input type="text" style="width: 510px;" value="<?php echo $row77['username'] ?>" disabled>
                                <input type="hidden" value="<?php echo $row77['username'] ?>" name="name" style="width: 510px;">
                            </td>
                        </tr>

                        <td>&nbsp;</td>
                        <tr><td>
                                <label for="designation">Designation </label></td>


                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


                                <input type="text" style="width: 510px;" value="<?php echo $row77['user_designation'] ?>" disabled>
                                <input type="hidden" value="<?php echo $row77['user_designation'] ?>" name="designation" style="width: 510px;">
                            </td>
                        </tr>
                        <td>&nbsp;</td>

                        <tr><td>
                                <label for="date4">Date </label></td>

                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                <input type="text" style="width: 200px;" value="<?php echo date("d/m/Y") ?>" disabled>
                                <input type="hidden" name="date2" id="date2" style="width: 200px;" value="<?php echo date(d / m / Y) ?>">
                            </td>
                        </tr>

                    </table>





                    <br />

                    <div style="margin-left: 265px;" >
                        <table><tr><td>
                                    <input class="btn btn-info" type="submit" value="OK"></td>
                                <td>&nbsp;
                                    <input class="btn btn-info" type="submit" value="Cancel"></td>
                            </tr>
                        </table>

                    </div>




            </form> 





        </body>

</html>

