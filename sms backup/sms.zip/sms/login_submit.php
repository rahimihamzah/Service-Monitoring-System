<?php

include "connection.php";
session_start();

$user = $_POST['username'];
$pass = $_POST['password'];

$sql = "SELECT * FROM main_admin WHERE admin_username='$user' AND admin_password='$pass'";
$sql2 = "SELECT * FROM [user] where user_id='$user' and password='$pass'";
$params = array();
$options = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
$params2 = array();
$options2 = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
$stmt = sqlsrv_query($conn, $sql, $params, $options);
$stmt2 = sqlsrv_query($conn, $sql2, $params2, $options2);

$row_count = sqlsrv_num_rows($stmt);
$row_count2 = sqlsrv_num_rows($stmt2);

if ($row_count > 0) {
    //get user_id value
    $result0 = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    if ($result0) {
        $user_id = $result0['id_admin'];

        $_SESSION['username'] = $user;
        $_SESSION['id_admin'] = $user_id;

        //die($_SESSION['username'].":".$_SESSION['id_admin']);

        header("Location:admin/home.php");
    }
} else if ($row_count2 > 0) {
    //echo $row_count2;
    //$row2 = sqlsrv_fetch_array($stmt2);
    //get user_id value
    $result1 = sqlsrv_fetch_array($stmt2, SQLSRV_FETCH_ASSOC);
    if ($result1) {
        // echo $result1;
        //die();
        $user_id = $result1['user_id'];

        $_SESSION['username'] = $user;
        $_SESSION['user_id'] = $user_id;

        //die($_SESSION['username'].":".$_SESSION['user_id']);

        header("Location:user/home.php");
    }
} else {

    $message = "Error Message : Incorrect username or password!";
    echo "<script type='text/javascript'>alert('$message');
			window.location = 'index.php';</script>";
}
?>