<link rel="stylesheet" href="css/style.css">
<?php
$id=null;
if(isset($_GET['id']))
{
	$id=$_GET['id'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Set Password</title>
</head>

<body>

                <!-- /.col-lg-12 -->
            </div>
            <form action="password_submit.php" method="POST">
            <table>
            <header>Insert Your Password</header>
            <tr>
            <td><label>New Password<span>&nbsp;&nbsp;&nbsp;*</span></label></td>
            </tr>


            <tr>
            <td>
            <input type="password" name="user_pass" style="width:300px" required />
            </td></tr>
            <td>
            &nbsp;
            </td>
            <tr>
            <td><label>Confirm Password<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*</span></label></td>
            </tr>
            <tr>
            <td>
            <input type="password" name="user_pass1" style="width:300px" required/>
            </td>
            </tr>
            </table>
            <input type="hidden" name="id" value="<?php echo $id?>" />
            <br />
            
            
            <div></div>
            <button name="submit" type="submit" value="Submit">Submit</button>
            
</body>
</html>