<?php

$serverName = 'GEEZERS';
$connectionInfo = array('Database'=>'sms');
$conn = sqlsrv_connect( $serverName, $connectionInfo);



?>